local localizations = {}								
								
local researchName = "Indagare"			
local researchingName = "Indagare"			
								
localizations.values = {
gameName = "Sapiens",
sapiens = "Sapiens",
								
-- mobs
mob_alpaca = "Alpaca",
mob_alpaca_plural = "Alpaca",
mob_chicken = "Pollo",
mob_chicken_plural = "Polli",
mob_mammoth = "Mammut",
mob_mammoth_plural = "Mammut",
								
-- buildables
buildable_craftArea = "Area artigianale",
buildable_craftArea_plural = "Aree di lavorazione",
buildable_craftArea_summary = "Crea oggetti di base, strumenti semplici.",
buildable_storageArea = "Deposito",
buildable_storageArea_plural = "Aree di stoccaggio",
buildable_storageArea_summary = "Raccogli tutto ciò che hai in giro e riponilo in una pila ordinata.",
buildable_campfire = "Falò",
buildable_campfire_plural = "Fuochi",
buildable_campfire_summary = "Il fuoco fornisce calore e luce e consente di cucinare il cibo per aumentarne il valore nutritivo.",
buildable_brickKiln = "Forno",
buildable_brickKiln_plural = "Forni",
buildable_brickKiln_summary = "I forni possono essere usati per cuocere la ceramica. La ceramica cotta è più resistente all'acqua e durerà più a lungo della ceramica cruda.",
buildable_torch = "Torcia",
buildable_torch_plural = "Torce",
buildable_torch_summary = "Fornisce luce. Il fieno deve essere sostituito frequentemente.",
buildable_hayBed = "Letto di fieno",
buildable_hayBed_plural = "letti di fieno",
buildable_hayBed_summary = "Meglio che dormire sul terreno duro.",
buildable_woolskinBed = "Letto in lana",
buildable_woolskinBed_plural = "Letti in lana",
buildable_woolskinBed_summary = "Un posto caldo dove dormire.",
buildable_thatchRoof = "Capanna/tetto di paglia",
buildable_thatchRoof_plural = "Capanne/tetti di paglia",
buildable_thatchRoof_summary = "Una pensilina di base, utilizzabile anche come tettoia.",
buildable_thatchRoofLarge = "Grande tetto di paglia",
buildable_thatchRoofLarge_plural = "Grandi tetti di paglia",
buildable_thatchRoofLarge_summary = "Una grande sezione del tetto.",
buildable_thatchRoofLargeCorner = "Ampio angolo del tetto di paglia",
buildable_thatchRoofLargeCorner_plural = "Grandi angoli del tetto di paglia",
buildable_thatchRoofLargeCorner_summary = "Una grande sezione del tetto.",
buildable_thatchWall = "Muro di paglia",
buildable_thatchWall_plural = "Muri di paglia",
buildable_thatchWall_summary = "Il muro più semplice e veloce da costruire. Dimensioni: 4x2",
buildable_thatchWallDoor = "Muro Di Paglia Con Porta",
buildable_thatchWallDoor_plural = "Pareti Di Paglia Con Porte",
buildable_thatchWallDoor_summary = "Il muro più semplice e veloce da costruire. Dimensioni: 4x2",
buildable_thatchWallLargeWindow = "Finestra singola a parete di paglia",
buildable_thatchWallLargeWindow_plural = "Finestre singole con pareti di paglia",
buildable_thatchWallLargeWindow_summary = "Il muro più semplice e veloce da costruire. Dimensioni: 4x2",
buildable_thatchWall4x1 = "Muro corto di paglia",
buildable_thatchWall4x1_plural = "Muri corti di paglia",
buildable_thatchWall4x1_summary = "Il muro più semplice e veloce da costruire. Dimensioni: 4x1",
buildable_thatchWall2x2 = "Muro quadrato di paglia",
buildable_thatchWall2x2_plural = "Pareti quadrate di paglia",
buildable_thatchWall2x2_summary = "Il muro più semplice e veloce da costruire. Dimensioni: 2x2",
buildable_thatchRoofEnd = "Parete del tetto di paglia",
buildable_thatchRoofEnd_plural = "Pareti del tetto di paglia",
buildable_thatchRoofEnd_summary = "Il muro più semplice e veloce da costruire.",
buildable_splitLogFloor = "Piano in legno diviso 2x2",
buildable_splitLogFloor_plural = "Piano in legno diviso 2x2",
buildable_splitLogFloor_summary = "Un pavimento semplice.",
buildable_splitLogFloor4x4 = "Dividi il piano di tronchi 4x4",
buildable_splitLogFloor4x4_plural = "Split Log Floor 4x4",
buildable_splitLogFloor4x4_summary = "Un pavimento semplice.",
buildable_splitLogWall = "Muro di tronchi diviso",
buildable_splitLogWall_plural = "Dividi pareti di tronchi",
buildable_splitLogWall_summary = "Un robusto muro di legno. Dimensioni: 4x2",
buildable_splitLogWall4x1 = "Parete corta del ceppo diviso",
buildable_splitLogWall4x1_plural = "Spacca le pareti corte del ceppo",
buildable_splitLogWall4x1_summary = "Un robusto muro di legno. Dimensioni: 4x1",
buildable_splitLogWall2x2 = "Parete quadrata del ceppo diviso",
buildable_splitLogWall2x2_plural = "Spacca le pareti quadrate del ceppo",
buildable_splitLogWall2x2_summary = "Un robusto muro di legno. Dimensioni: 2x2",
buildable_splitLogWallDoor = "Muro Di Ceppo Diviso Con Porta",
buildable_splitLogWallDoor_plural = "Diviso Log Pareti Con Porte",
buildable_splitLogWallDoor_summary = "Un robusto muro di legno. Dimensioni: 4x2",
buildable_splitLogWallLargeWindow = "Muro Di Tronchi Diviso Con Ampia Finestra",
buildable_splitLogWallLargeWindow_plural = "Dividi pareti di tronchi con grandi finestre",
buildable_splitLogWallLargeWindow_summary = "Un robusto muro di legno. Dimensioni: 4x2",
buildable_splitLogRoofEnd = "Parete del tetto in legno diviso",
buildable_splitLogRoofEnd_plural = "Dividi le pareti del tetto in tronchi",
buildable_splitLogRoofEnd_summary = "Un robusto muro di legno.",
buildable_splitLogBench = "Banco di tronchi spaccati",
buildable_splitLogBench_plural = "Panche di tronchi divisi",
buildable_splitLogBench_summary = "Un buon posto per sedersi.",
buildable_splitLogSteps = "Dividi Log Passi 2x3 Piano Singolo",
buildable_splitLogSteps_plural = "Dividi Log Passi 2x3 Piano Singolo",
buildable_splitLogSteps_summary = "Per spostarsi tra i piani o in salita.",
buildable_splitLogSteps2x2 = "Dividi i passaggi del registro 2x2 a metà piano",
buildable_splitLogSteps2x2_plural = "Dividi i passaggi del registro 2x2 a metà piano",
buildable_splitLogSteps2x2_summary = "Per spostarsi tra i piani o in salita.",
buildable_splitLogRoof = "Capanna/tetto diviso in tronchi",
buildable_splitLogRoof_plural = "Dividi capanne/tetti di tronchi",
buildable_splitLogRoof_summary = "Una tettoia robusta, utilizzabile anche come tettoia.",
buildable_mudBrickWall = "Muro di mattoni di fango",
buildable_mudBrickWall_plural = "Muri di mattoni di fango",
buildable_mudBrickWall_summary = "Un muro robusto. Dimensioni: 4x2",
buildable_mudBrickWallDoor = "Muro Di Mattoni Con Porta",
buildable_mudBrickWallDoor_plural = "Mudbrick Mud Con Porte",
buildable_mudBrickWallDoor_summary = "Un muro robusto. Dimensioni: 4x2",
buildable_mudBrickWallLargeWindow = "Muro Di Mattoni Con Grande Finestra",
buildable_mudBrickWallLargeWindow_plural = "Mudbrick Mud Con Grandi Finestre",
buildable_mudBrickWallLargeWindow_summary = "Un muro robusto. Dimensioni: 4x2",
buildable_mudBrickWall4x1 = "Mezza parete in laterizio",
buildable_mudBrickWall4x1_plural = "Mezze pareti in laterizio",
buildable_mudBrickWall4x1_summary = "Un muro robusto. Dimensioni: 4x1",
buildable_mudBrickWall2x2 = "Muro quadrato di mattoni di fango",
buildable_mudBrickWall2x2_plural = "Muri quadrati di mattoni di fango",
buildable_mudBrickWall2x2_summary = "Un muro robusto. Dimensioni: 2x2",
buildable_mudBrickColumn = "Colonna di fango",
buildable_mudBrickColumn_plural = "Colonne di fango",
buildable_mudBrickColumn_summary = "Una colonna decorativa.",
buildable_mudBrickFloor2x2 = "Pavimento in mattoni di fango 2x2",
buildable_mudBrickFloor2x2_plural = "Pavimento in mattoni di fango 2x2s",
buildable_mudBrickFloor2x2_summary = "Una buona scelta per luoghi asciutti.",
buildable_mudBrickFloor4x4 = "Pavimento in laterizio 4x4",
buildable_mudBrickFloor4x4_plural = "Pavimento in mattoni di fango 4x4",
buildable_mudBrickFloor4x4_summary = "Una buona scelta per luoghi asciutti.",
buildable_brickWall = "Muro di mattoni",
buildable_brickWall_plural = "Muri di mattoni",
buildable_brickWall_summary = "Un muro robusto. Dimensioni: 4x2",
buildable_brickWallDoor = "Muro Di Mattoni Con Porta",
buildable_brickWallDoor_plural = "Muri Di Mattoni Con Porte",
buildable_brickWallDoor_summary = "Un muro robusto. Dimensioni: 4x2",
buildable_brickWallLargeWindow = "Muro Di Mattoni Con Grande Finestra",
buildable_brickWallLargeWindow_plural = "Muri Di Mattoni Con Grandi Finestre",
buildable_brickWallLargeWindow_summary = "Un muro robusto. Dimensioni: 4x2",
buildable_brickWall4x1 = "Mezza parete di mattoni",
buildable_brickWall4x1_plural = "Mezze pareti in mattoni",
buildable_brickWall4x1_summary = "Un muro robusto. Dimensioni: 4x1",
buildable_brickWall2x2 = "Muro quadrato di mattoni",
buildable_brickWall2x2_plural = "Muri quadrati di mattoni",
buildable_brickWall2x2_summary = "Un muro robusto. Dimensioni: 2x2",
buildable_tileFloor2x2 = "Pavimento in piastrelle 2x2",
buildable_tileFloor2x2_plural = "Pavimento in piastrelle 2x2s",
buildable_tileFloor2x2_summary = "Fascino rustico.",
buildable_tileFloor4x4 = "Pavimento in piastrelle 4x4",
buildable_tileFloor4x4_plural = "Pavimento in piastrelle 4x4",
buildable_tileFloor4x4_summary = "Fascino rustico.",
buildable_genericPath_summary = "I percorsi consentono ai sapiens di muoversi più velocemente.",
buildable_tileRoof = "Capanna/tetto di tegole",
buildable_tileRoof_plural = "Capanne/tetti di tegole",
buildable_tileRoof_summary = "Un robusto tetto resistente alle intemperie.",

--craftables
craftable_rockSmall = "Piccola Roccia",
craftable_rockSmall_plural = "Piccole rocce",
craftable_rockSmall_summary = "Può essere trasformato in strumenti di base.",
craftable_stoneSpearHead = "Testa di lancia di pietra",
craftable_stoneSpearHead_plural = "Punte di lancia di pietra",
craftable_stoneSpearHead_summary = "Usato per fare lance di pietra.",
craftable_stonePickaxeHead = "Testa di piccone di pietra",
craftable_stonePickaxeHead_plural = "Teste di piccone di pietra",
craftable_stonePickaxeHead_summary = "Usato per fare picconi di pietra.",
craftable_flintSpearHead = "Testa di lancia di selce",
craftable_flintSpearHead_plural = "Punte di lancia di selce",
craftable_flintSpearHead_summary = "Usato per fare lance di selce.",
craftable_boneSpearHead = "Testa di lancia in osso",
craftable_boneSpearHead_plural = "Punte di lancia in osso",
craftable_boneSpearHead_summary = "Usato per fare lance d'osso.",
craftable_stoneKnife = "Coltello di pietra",
craftable_stoneKnife_plural = "Coltelli di pietra",
craftable_stoneKnife_summary = "Utilizzato per molte cose, inclusa la macellazione e la lavorazione del legno.",
craftable_quernstone = "Quern-pietra",
craftable_quernstone_plural = "Quern-pietre",
craftable_quernstone_summary = "Usato per la macinazione, può macinare il grano in farina.",
craftable_flintKnife = "Coltello di selce",
craftable_flintKnife_plural = "Coltelli di selce",
craftable_flintKnife_summary = "Utilizzato per molte cose, inclusa la macellazione e la lavorazione del legno.",
craftable_boneKnife = "Coltello d'osso",
craftable_boneKnife_plural = "Coltelli d'osso",
craftable_boneKnife_summary = "Utilizzato per molte cose, inclusa la macellazione e la lavorazione del legno.",
craftable_boneFlute = "Flauto d'osso",
craftable_boneFlute_plural = "Flauti d'osso",
craftable_boneFlute_summary = "La musica aiuta a mantenere felici i sapiens.",
craftable_logDrum = "Log tamburo",
craftable_logDrum_plural = "Log tamburi",
craftable_logDrum_summary = "La musica aiuta a mantenere felici i sapiens.",
craftable_balafon = "Balafon",
craftable_balafon_plural = "Balafons",
craftable_balafon_summary = "La musica aiuta a mantenere felici i sapiens.",
craftable_flintPickaxeHead = "Testa di piccone di selce",
craftable_flintPickaxeHead_plural = "Teste di piccone di selce",
craftable_flintPickaxeHead_summary = "Usato per fare picconi di selce.",
craftable_woodenPole = "Palo di legno (obsoleto)",
craftable_woodenPole_plural = "Pali di legno (obsoleto)",
craftable_woodenPole_summary = "Presto verrà rimosso dal gioco.",
craftable_stoneSpear = "Lancia di pietra",
craftable_stoneSpear_plural = "Lance di pietra",
craftable_stoneSpear_summary = "Usato per caccia, pesca e combattimento.",
craftable_flintSpear = "Lancia di selce",
craftable_flintSpear_plural = "Lance di selce",
craftable_flintSpear_summary = "Usato per caccia, pesca e combattimento.",
craftable_boneSpear = "Lancia d'ossa",
craftable_boneSpear_plural = "Lance d'osso",
craftable_boneSpear_summary = "Usato per caccia, pesca e combattimento.",
craftable_stonePickaxe = "Piccone di pietra",
craftable_stonePickaxe_plural = "Picconi di pietra",
craftable_stonePickaxe_summary = "Può essere usato per estrarre roccia e anche per scavare più facilmente.",
craftable_flintPickaxe = "Piccone di selce",
craftable_flintPickaxe_plural = "Picconi di selce",
craftable_flintPickaxe_summary = "Può essere usato per estrarre roccia e anche per scavare più facilmente.",
craftable_stoneHatchet = "Ascia di pietra",
craftable_stoneHatchet_plural = "Asce di pietra",
craftable_stoneHatchet_summary = "Buono per tagliare gli alberi.",
craftable_stoneAxeHead = "Ascia di pietra",
craftable_stoneAxeHead_plural = "Asce in pietra",
craftable_stoneAxeHead_summary = "Può essere usato per tagliare la legna e scavare il terreno.",
craftable_flintAxeHead = "Ascia a mano in selce",
craftable_flintAxeHead_plural = "Asce a mano in selce",
craftable_flintAxeHead_summary = "Può essere usato per tagliare la legna e scavare il terreno.",
craftable_flintHatchet = "Ascia di selce",
craftable_flintHatchet_plural = "Asce di selce",
craftable_flintHatchet_summary = "Buono per tagliare gli alberi.",
craftable_splitLog = "Registro diviso",
craftable_splitLog_plural = "Registri divisi",				
craftable_butcherChicken = "Pollo Al Macellaio",
craftable_butcherChicken_plural = "Polli Da Macellaio",
craftable_butcherChicken_summary = "Raccogli la carne dal pollo.",
craftable_butcherAlpaca = "Macellaio Alpaca",
craftable_butcherAlpaca_plural = "Alpaca del macellaio",
craftable_butcherAlpaca_summary = "Raccogli carne e lana dall'alpaca.",
craftable_cookedChicken = "Carne Di Pollo Cotta",
craftable_cookedChicken_plural = "Carne Di Pollo Cotta",
craftable_cookedChicken_summary = "Vincitore vincitore.",
craftable_campfireRoastedPumpkin = "Zucca arrostita al fuoco",
craftable_campfireRoastedPumpkin_plural = "Zucca arrostita al fuoco",
craftable_campfireRoastedPumpkin_summary = "Goloso.",
craftable_campfireRoastedBeetroot = "Barbabietola arrostita al fuoco",
craftable_campfireRoastedBeetroot_plural = "Barbabietola arrostita al fuoco",
craftable_campfireRoastedBeetroot_summary = "Barbabietole che lo mangiano crudo.",
craftable_flatbread = "Focaccia",
craftable_flatbread_plural = "Focacce",
craftable_flatbread_summary = "Il pane più semplice",
craftable_unfiredUrnWet = "Urna non cotta",
craftable_unfiredUrnWet_plural = "Urne crude",
craftable_unfiredUrnWet_summary = "Può essere utilizzato per raccogliere e conservare i cereali. Mantiene i chicchi più a lungo se cotti.",
craftable_firedUrn = "Urna licenziata",
craftable_firedUrn_plural = "Urne cotte",
craftable_firedUrn_summary = "Può essere utilizzato per raccogliere e conservare i cereali. Mantiene i chicchi più a lungo se cotti.",
craftable_hulledWheat = "Grano decorticato",
craftable_hulledWheat_plural = "Grano decorticato",
craftable_hulledWheat_summary = "Può essere usato per fare le zucchine o trasformato in farina.",
craftable_thatchResearch = "Ricerca di paglia",
craftable_thatchResearch_plural = "Ricerca di paglia",
craftable_thatchResearch_summary = "Ricerca di paglia.",
craftable_mudBrickBuildingResearch = "Ricerca sulla costruzione di mattoni di fango",
craftable_mudBrickBuildingResearch_plural = "Ricerca sulla costruzione di mattoni di fango",
craftable_mudBrickBuildingResearch_summary = "Ricerca sulla costruzione di mattoni di fango.",
craftable_woodBuildingResearch = "Ricerca sull'edilizia in legno",
craftable_woodBuildingResearch_plural = "Ricerca sull'edilizia in legno",
craftable_woodBuildingResearch_summary = "Ricerca sull'edilizia in legno.",
craftable_brickBuildingResearch = "Ricerca sulla costruzione di mattoni",
craftable_brickBuildingResearch_plural = "Ricerca sulla costruzione di mattoni",
craftable_brickBuildingResearch_summary = "Ricerca sulla costruzione di mattoni.",
craftable_tilingResearch = "Ricerca sulla piastrellatura",
craftable_tilingResearch_plural = "Ricerca sulla piastrellatura",
craftable_tilingResearch_summary = "Ricerca sulla piastrellatura.",
craftable_plantingResearch = "Ricerca sulla semina.",
craftable_plantingResearch_plural = "Ricerca sulla semina",
craftable_plantingResearch_summary = "Ricerca sulla semina.",
craftable_flour = "Farina",
craftable_flour_plural = "Farina",
craftable_flour_summary = "Usato per fare il pane.",
craftable_breadDough = "Impasto Di Pane",
craftable_breadDough_plural = "Impasto Di Pane",
craftable_breadDough_summary = "Può essere cotto nel pane.",
craftable_flaxTwine = "Spago di lino",
craftable_flaxTwine_plural = "Spago di lino",
craftable_flaxTwine_summary = "Utilizzato per la fabbricazione di strumenti più avanzati e la tessitura.",
craftable_mudBrickWet = "Mattoni di fango",
craftable_mudBrickWet_plural = "Mattoni di fango",
craftable_mudBrickWet_summary = "Una volta asciutto, può essere utilizzato per la costruzione di pensiline, oltre che per la costruzione di forni.",
craftable_mudTileWet = "Piastrella cruda",
craftable_mudTileWet_plural = "Piastrelle crude",
craftable_mudTileWet_summary = "Una volta essiccato e cotto, può essere utilizzato per tetti, pavimenti e vialetti.",
craftable_firedTile = "Piastrella",
craftable_firedTile_plural = "Piastrelle",
craftable_firedTile_summary = "Può essere utilizzato per tetti, pavimenti e percorsi.",
craftable_cookedAlpaca = "Carne di Alpaca Cotta",
craftable_cookedAlpaca_plural = "Carne di Alpaca Cotta",
craftable_cookedAlpaca_summary = "Una gamba o una cremagliera possono sfamare una famiglia numerosa.",
craftable_cookedMammoth = "Carne di mammut cotta",
craftable_cookedMammoth_plural = "Carne di mammut cotta",
craftable_cookedMammoth_summary = "Sa di elefante peloso.",
craftable_firedBrick = "Mattone",
craftable_firedBrick_plural = "Mattoni",
craftable_firedBrick_summary = "Una risorsa durevole con cui costruire.",
								
--actions
action_idle = "Oziare",
action_idle_inProgress = "Oziare",
action_gather = "Mettere insieme",
action_gather_inProgress = "Raccolta",
action_chop = "Taglio",
action_chop_inProgress = "Tritare",
action_pullOut = "Tira fuori",
action_pullOut_inProgress = "Tirando fuori",
action_dig = "Scavare",
action_dig_inProgress = "Scavando",
action_mine = "Il mio",
action_mine_inProgress = "Estrazione",
action_clear = "Chiaro",
action_clear_inProgress = "Cancellazione",
action_moveTo = "Spostare",
action_moveTo_inProgress = "In movimento",
action_flee = "Fuggire",
action_flee_inProgress = "Fuggendo",
action_pickup = "Raccogliere",
action_pickup_inProgress = "Raccogliere",
action_place = "Posto",
action_place_inProgress = "Posizionamento",
action_eat = "Mangiare",
action_eat_inProgress = "Mangiare",
action_playFlute = "Giocare a",
action_playFlute_inProgress = "Giocando",
action_playDrum = "Giocare a",
action_playDrum_inProgress = "Giocando",
action_playBalafon = "Giocare a",
action_playBalafon_inProgress = "Giocando",
action_wave = "Onda",
action_wave_inProgress = "Agitando",
action_turn = "Giro",
action_turn_inProgress = "Girando",
action_fall = "Autunno",
action_fall_inProgress = "Cadente",
action_sleep = "Sonno",
action_sleep_inProgress = "Dormire",
action_build = "Costruire",
action_build_inProgress = "Costruzione",
action_light = "Luce",
action_light_inProgress = "Illuminazione",
action_extinguish = "Spegnere",
action_extinguish_inProgress = "Estinguente",
action_destroyContents = "Distruggi contenuti",
action_destroyContents_inProgress = "Contenuti distruttivi",
action_throwProjectile = "Gettare",
action_throwProjectile_inProgress = "Lancio",
action_butcher = "Macellaio",
action_butcher_inProgress = "Macellazione",
action_knap = "Knap",
action_knap_inProgress = "Knapping",
action_grind = "Macinare",
action_grind_inProgress = "Rettifica",
action_potteryCraft = "Mestiere",
action_potteryCraft_inProgress = "Artigianato",
action_spinCraft = "Mestiere",
action_spinCraft_inProgress = "Artigianato",
action_thresh = "Trebbiare",
action_thresh_inProgress = "Trebbiatura",
action_scrapeWood = "Mestiere",
action_scrapeWood_inProgress = "Artigianato",
action_fireStickCook = "Cucinare",
action_fireStickCook_inProgress = "cucinando",
action_recruit = "Reclutare",
action_recruit_inProgress = "Reclutamento",
action_sneak = "Sgattaiolare",
action_sneak_inProgress = "furtivamente",
action_sit = "Sedersi",
action_sit_inProgress = "Seduta",
action_inspect = "Ispezionare",
action_inspect_inProgress = "Ispezionare",
action_patDown = "Ordinata",
action_patDown_inProgress = "Riordinare",
action_takeOffTorsoClothing = "Togliti i vestiti",
action_takeOffTorsoClothing_inProgress = "Togliersi i vestiti",
action_putOnTorsoClothing = "Indossare i vestiti",
action_putOnTorsoClothing_inProgress = "Indossare abiti",
								
--action modifiers
action_jog = "Fare jogging",
action_jog_inProgress = "Jogging",
action_run = "Correre",
action_run_inProgress = "In esecuzione",
action_slowWalk = "Camminata lenta",
action_slowWalk_inProgress = "Camminando lentamente",
action_sadWalk = "Triste passeggiata",
action_sadWalk_inProgress = "Camminando tristemente",
action_crouch = "Accovacciarsi",
action_crouch_inProgress = "Accovacciato",
								
-- terrain types
terrain_rock = "Roccia",
terrain_limestone = "Calcare",
terrain_redRock = "roccia rossa",
terrain_greenRock = "Pietraverde",
terrain_beachSand = "Sabbia",
terrain_riverSand = "Sabbia di fiume",
terrain_desertSand = "Sabbia",
terrain_ice = "Ghiaccio",
terrain_desertRedSand = "Sabbia rossa del deserto",
terrain_dirt = "Suolo",
terrain_richDirt = "Suolo fertile",
terrain_poorDirt = "Terreno povero",
terrain_clay = "Argilla",
								
-- terrain variations
terrainVariations_snow = "Neve",
terrainVariations_grassSnow = "Erba/neve",
terrainVariations_grass = "Erba",
terrainVariations_flint = "pietra focaia",
terrainVariations_clay = "Argilla",
terrainVariations_limestone = "Calcare",
terrainVariations_redRock = "roccia rossa",
terrainVariations_greenRock = "Pietraverde",
terrainVariations_shallowWater = "Acque poco profonde",
terrainVariations_deepWater = "Acque profonde",
								
-- needs
need_sleep = "Sonno",
need_warmth = "Calore",
need_food = "Fame",
need_rest = "riposo",
need_starvation = "Affamato",
need_exhaustion = "Esausto",
need_music = "Musica",
								
--flora
flora_willow = "Salice",
flora_willow_plural = "Salici",
flora_willow_summary = "Trovato vicino ai fiumi, i salici forniscono un legno forte ma contorto.",
flora_willow_sapling = "Alberello di salice",
flora_willow_sapling_plural = "Alberelli di salice",
flora_beetrootPlant = "Barbabietola",
flora_beetrootPlant_plural = "Barbabietole",
flora_beetrootPlant_summary = "Un delizioso ortaggio a radice rustica.",
flora_beetrootPlantSapling = "Semenzale di barbabietola",
flora_beetrootPlantSapling_plural = "Piantine di barbabietola",
flora_wheatPlant = "Grano",
flora_wheatPlant_plural = "Grano",
flora_wheatPlant_summary = "Il grano può essere trebbiato e poi macinato in farina per fare il pane.",
flora_wheatPlantSapling = "Semenzale di grano",
flora_wheatPlantSapling_plural = "Piantine di grano",
flora_flaxPlant = "Lino",
flora_flaxPlant_plural = "Lino",
flora_flaxPlant_summary = "Una pianta versatile, le fibre di lino possono essere filate in spago e i semi possono essere mangiati per una piccola quantità di calorie.",
flora_flaxPlantSapling = "Semenzale di lino",
flora_flaxPlantSapling_plural = "Piantine di lino",
flora_aspen = "Aspen Tree",
flora_aspen_plural = "Alberi di pioppo tremulo",
flora_aspen_summary = "Un alto albero a foglie caduche originario delle regioni fredde. Fornisce un legno chiaro con corteccia bianca.",
flora_aspen_sapling = "Alberello di pioppo tremulo",
flora_aspen_sapling_plural = "alberelli di pioppo tremulo",
flora_bamboo = "Bambù",
flora_bamboo_plural = "Bambù",
flora_bamboo_summary = "Il bambù cresce rapidamente e può essere utilizzato al posto dei rami degli alberi per costruire o legna da ardere.",
flora_bamboo_sapling = "Alberello di bambù",
flora_bamboo_sapling_plural = "Alberelli di bambù",
flora_palm = "Palma",
flora_palm_plural = "Palme",
flora_palm_summary = "Palma",
flora_palm_sapling = "Alberello di palma",
flora_palm_sapling_plural = "Alberelli di palma",
flora_birch = "Betulla",
flora_birch_plural = "Betulle",
flora_birch_summary = "Albero deciduo abbastanza compatto che fornisce un legno chiaro con corteccia bianca.",
flora_birch_sapling = "Alberello di betulla",
flora_birch_sapling_plural = "Alberelli di betulla",
flora_pine = "Pino",
flora_pine_plural = "Pini",
flora_pine_summary = "I pini si trovano in tutto il mondo e forniscono molto legno, oltre a pigne che possono essere bruciate.",
flora_pine_sapling = "Alberello di pino",
flora_pine_sapling_plural = "Alberelli di pino",
flora_pineBig = "Pino alto",
flora_pineBig_plural = "Alti pini",
flora_pineBig_summary = "I pini alti sono rari, richiedono molto tempo per crescere e producono semi solo ogni dieci anni, ma forniscono una grande quantità di legno quando vengono tagliati.",
flora_pineBig_sapling = "Alberello di pino alto",
flora_pineBig_sapling_plural = "Alberelli di pino alti",
flora_aspenBig = "Albero di pioppo tremulo alto",
flora_aspenBig_plural = "Alti alberi di pioppo tremulo",
flora_aspenBig_summary = "I pioppi alti sono rari, impiegano molto tempo per crescere e producono semi solo ogni dieci anni, ma forniscono una grande quantità di legno quando vengono tagliati.",
flora_aspenBig_sapling = "Alberello di Aspen alto",
flora_aspenBig_sapling_plural = "Alberelli di pioppo tremulo",
flora_appleTree = "Albero di mele",
flora_appleTree_plural = "Alberi di mele",
flora_appleTree_summary = "Albero deciduo compatto, che fornisce frutti dalla tarda estate all'autunno.",
flora_appleTree_sapling = "Alberello di mele",
flora_appleTree_sapling_plural = "Alberelli di mele",
flora_gooseberryBush = "Cespuglio di uva spina",
flora_gooseberryBush_plural = "Cespugli di uva spina",
flora_gooseberryBush_summary = "Fornisce un frutto succoso, ricco di vitamina C. Raccolto in estate.",
flora_pumpkinPlant = "Pianta di zucca",
flora_pumpkinPlant_plural = "Piante di zucca",
flora_pumpkinPlant_summary = "Le zucche si conservano a lungo, sono buone da mangiare e possono essere utili anche per altre cose.",
flora_peachTree = "Albero di pesche",
flora_peachTree_plural = "alberi di pesco",
flora_peachTree_summary = "Fornisce un succoso frutto a nocciolo, pronto da mangiare in estate.",
flora_peachTree_sapling = "Alberello di pesca",
flora_peachTree_sapling_plural = "Alberelli di pesca",
flora_bananaTree = "Albero di banane",
flora_bananaTree_plural = "Banani",
flora_bananaTree_summary = "I banani in realtà non sono affatto alberi, ma erbe aromatiche e i frutti sono tecnicamente bacche. Bacche gialle lunghe.",
flora_bananaTree_sapling = "Alberello di banana",
flora_bananaTree_sapling_plural = "Alberelli di banane",
flora_coconutTree = "Albero di cocco",
flora_coconutTree_plural = "alberi di cocco",
flora_coconutTree_summary = "Il cocco offre un frutto grande e nutriente e un legno unico. Le noci di cocco che cadono uccidono 150 persone ogni anno.",
flora_coconutTree_sapling = "Alberello di cocco",
flora_coconutTree_sapling_plural = "Alberelli di cocco",
flora_raspberryBush = "Cespuglio di lamponi",
flora_raspberryBush_plural = "Cespugli di lamponi",
flora_raspberryBush_summary = "I lamponi sono ricchi di vitamina C e pieni di sapore. Raccolto in autunno.",
flora_shrub = "Cespuglio",
flora_shrub_plural = "Cespugli",
flora_shrub_summary = "Cespuglio",
flora_orangeTree = "Albero di arance",
flora_orangeTree_plural = "Aranci",
flora_orangeTree_summary = "Gli aranci sono resistenti e forniscono un raccolto spesso tanto necessario nel tardo inverno.",
flora_orangeTree_sapling = "Alberello arancione",
flora_orangeTree_sapling_plural = "Alberelli arancioni",
flora_cactus = "Cactus",
flora_cactus_plural = "cactus",
flora_cactus_summary = "Cactus",
flora_cactus_sapling = "Alberello di cactus",
flora_cactus_sapling_plural = "Alberelli di cactus",
flora_sunflower = "Girasole",
flora_sunflower_plural = "Girasoli",
flora_sunflower_summary = "I girasoli illuminano il paesaggio e i semi forniscono una piccola quantità di calorie.",
flora_sunflowerSapling = "Alberello di girasole",
flora_sunflowerSapling_plural = "Alberelli di girasole",
flora_flower1 = "Fiore",
flora_flower1_plural = "Fiori",
flora_flower1_summary = "Fiore",
								
-- branches
branch_birch = "Ramo di betulla",
branch_birch_plural = "Rami di betulla",
branch_pine = "Ramo di pino",
branch_pine_plural = "Rami di pino",
branch_aspen = "Ramo di Aspen",
branch_aspen_plural = "Rami di pioppo tremulo",
branch_bamboo = "Bambù",
branch_bamboo_plural = "Bambù",
branch_willow = "Ramo di salice",
branch_willow_plural = "Rami di salice",
branch_apple = "Ramo di mela",
branch_apple_plural = "Rami di mele",
branch_orange = "Ramo d'Arancio",
branch_orange_plural = "Rami d'Arancio",
branch_peach = "Ramo di pesca",
branch_peach_plural = "Rami di pesco",
								
-- logs
log_birch = "Registro di betulla",
log_birch_plural = "Tronchi di betulla",
log_willow = "Registro di salice",
log_willow_plural = "Tronchi di salice",
log_apple = "Registro di Apple",
log_apple_plural = "Registri Apple",
log_orange = "Registro arancione",
log_orange_plural = "Tronchi arancioni",
log_peach = "Registro di pesca",
log_peach_plural = "Registri di pesca",
log_pine = "Tronco di pino",
log_pine_plural = "Tronchi di pino",
log_aspen = "Registro dell'Aspen",
log_aspen_plural = "Registri dell'Aspen",
log_coconut = "Registro di cocco",
log_coconut_plural = "Tronchi di cocco",
								
--fruits/seeds
fruit_orange = "Arancia",
fruit_orange_plural = "Arance",
fruit_orange_rotten = "Arancio marcio",
fruit_orange_rotten_plural = "Arance Marce",
fruit_apple = "Mela",
fruit_apple_plural = "Mele",
fruit_apple_rotten = "Mela marcia",
fruit_apple_rotten_plural = "Mele Marce",
fruit_banana = "Banana",
fruit_banana_plural = "Banane",
fruit_banana_rotten = "Banana marcia",
fruit_banana_rotten_plural = "Banane Marce",
fruit_coconut = "Noce di cocco",
fruit_coconut_plural = "Noci di cocco",
fruit_coconut_rotten = "Noce di cocco marcio",
fruit_coconut_rotten_plural = "Noci di cocco marce",
fruit_pineCone = "Pigna",
fruit_pineCone_plural = "Pigne",
fruit_pineCone_rotten = "Pigna marcia",
fruit_pineCone_rotten_plural = "Pigne marce",
fruit_pineConeBig = "Pigna grande",
fruit_pineConeBig_plural = "Grandi pigne",
fruit_pineConeBig_rotten = "Cono di pino grande marcio",
fruit_pineConeBig_rotten_plural = "Grandi pigne marce",
fruit_aspenBigSeed = "Seme di pioppo tremulo alto",
fruit_aspenBigSeed_plural = "Semi di pioppo tremulo alti",
fruit_aspenBigSeed_rotten = "Seme di pioppo tremulo alto marcio",
fruit_aspenBigSeed_rotten_plural = "Semi di pioppo tremulo alto marci",
fruit_beetroot = "Barbabietola",
fruit_beetroot_plural = "Barbabietole",
fruit_beetroot_rotten = "Barbabietola Marcia",
fruit_beetroot_rotten_plural = "Barbabietole Marce",
fruit_beetrootSeed = "Semi di barbabietola",
fruit_beetrootSeed_plural = "Semi di barbabietola",
fruit_beetrootSeed_rotten = "Semi di barbabietola marci",
fruit_beetrootSeed_rotten_plural = "Semi di barbabietola marci",
fruit_wheat = "Grano",
fruit_wheat_plural = "Grano",
fruit_wheat_rotten = "Grano Marcio",
fruit_wheat_rotten_plural = "Grano Marcio",
fruit_flax = "Lino bagnato",
fruit_flax_plural = "Lino bagnato",
fruit_flax_rotten = "Lino Marcio",
fruit_flax_rotten_plural = "Lino Marcio",
fruit_flaxSeed = "Semi di lino",
fruit_flaxSeed_plural = "Semi di lino",
fruit_flaxSeed_rotten = "Semi di lino marci",
fruit_flaxSeed_rotten_plural = "Semi di lino marci",
fruit_sunflowerSeed = "Semi di girasole",
fruit_sunflowerSeed_plural = "Semi di girasole",
fruit_sunflowerSeed_rotten = "Semi di girasole marci",
fruit_sunflowerSeed_rotten_plural = "Semi di girasole marci",
fruit_peach = "Pesca",
fruit_peach_plural = "Pesche",
fruit_peach_rotten = "Pesca Marcia",
fruit_peach_rotten_plural = "Pesche Marce",
fruit_raspberry = "Lampone",
fruit_raspberry_plural = "Lamponi",
fruit_raspberry_rotten = "Lampone Marcio",
fruit_raspberry_rotten_plural = "Lamponi Marci",
fruit_gooseberry = "Uva spina",
fruit_gooseberry_plural = "Uva spina",
fruit_gooseberry_rotten = "Uva spina marcia",
fruit_gooseberry_rotten_plural = "Uva Spina Marcia",
fruit_pumpkin = "Zucca",
fruit_pumpkin_plural = "Zucche",
fruit_pumpkin_rotten = "Zucca Marcia",
fruit_pumpkin_rotten_plural = "Zucche Marce",
fruit_birchSeed = "Seme di betulla",
fruit_birchSeed_plural = "Semi di betulla",
fruit_birchSeed_rotten = "Seme di betulla marcio",
fruit_birchSeed_rotten_plural = "Semi di betulla marci",
fruit_aspenSeed = "Seme di pioppo tremulo",
fruit_aspenSeed_plural = "Semi di pioppo tremulo",
fruit_aspenSeed_rotten = "Seme di pioppo tremulo marcio",
fruit_aspenSeed_rotten_plural = "Semi di pioppo tremulo marcio",
fruit_willowSeed = "Semi di salice",
fruit_willowSeed_plural = "Semi di salice",
fruit_willowSeed_rotten = "Seme di salice marcio",
fruit_willowSeed_rotten_plural = "Semi di salice marcio",
fruit_bambooSeed = "Seme di bambù",
fruit_bambooSeed_plural = "Semi di bambù",
fruit_bambooSeed_rotten = "Seme di bambù marcio",
fruit_bambooSeed_rotten_plural = "Semi di bambù marci",
								
-- tool groups
toolGroup_weapon = "Arma",
toolGroup_weapon_plural = "Armi",
								
-- tools
tool_treeChop = "Strumento per tagliare",
tool_treeChop_plural = "Strumenti per tagliare",
tool_treeChop_usage = "Tritare",
tool_dig = "Strumento di scavo",
tool_dig_plural = "Strumenti di scavo",
tool_dig_usage = "Scavando",
tool_mine = "Strumento di estrazione",
tool_mine_plural = "Strumenti minerari",
tool_mine_usage = "Estrazione",
tool_weaponBasic = "Arma di base",
tool_weaponBasic_plural = "Armi di base",
tool_weaponBasic_usage = "Arma (Base)",
tool_weaponSpear = "Lancia",
tool_weaponSpear_plural = "lance",
tool_weaponSpear_usage = "Arma (Lancia)",
tool_weaponKnife = "Coltello",
tool_weaponKnife_plural = "Coltelli",
tool_weaponKnife_usage = "Arma (coltello)",
tool_butcher = "Strumento di macellazione",
tool_butcher_plural = "Strumenti di macellazione",
tool_butcher_usage = "Macellazione",
tool_knapping = "Strumento Knapping",
tool_knapping_plural = "Strumenti di Knapping",
tool_knapping_usage = "Knapping",
tool_carving = "Strumento di intaglio",
tool_carving_plural = "Strumenti di intaglio",
tool_carving_usage = "Intaglio",
tool_grinding = "Strumento di rettifica",
tool_grinding_plural = "Strumenti di rettifica",
tool_grinding_usage = "Rettifica",
								
--tool properties
toolProperties_damage = "Danno",
toolProperties_speed = "Velocità",
toolProperties_durability = "Durabilità",
								
-- tool usages
tool_usage_new = "Nuovo",
tool_usage_used = "Usato",
tool_usage_wellUsed = "Usato bene",
tool_usage_nearlyBroken = "Quasi rotto",
								
-- plans
plan_build = "Costruire",
plan_build_inProgress = "Costruzione",
plan_plant = "Pianta",
plan_plant_inProgress = "Piantare",
plan_dig = "Scavare",
plan_dig_inProgress = "Scavando",
plan_mine = "Il mio",
plan_mine_inProgress = "Estrazione",
plan_clear = "Chiaro",
plan_clear_inProgress = "Cancellazione",
plan_fill = "Riempire",
plan_fill_inProgress = "Riempimento",
plan_chop = "Taglio",
plan_chop_inProgress = "Tritare",
plan_storeObject = "Negozio",
plan_storeObject_inProgress = "Memorizzazione",
plan_transferObject = "Trasferimento",
plan_transferObject_inProgress = "Trasferimento",
plan_destroyContents = "Distruggi contenuti",
plan_destroyContents_inProgress = "Contenuti distruttivi",
plan_pullOut = "Tira fuori",
plan_pullOut_inProgress = "Tirando fuori",
plan_removeObject = "Rimuovere",
plan_removeObject_inProgress = "Rimozione",
plan_gather = "Mettere insieme",
plan_gather_inProgress = "Raccolta",
plan_moveTo = "Spostare",
plan_moveTo_inProgress = "In movimento",
plan_wait = "Attendere qui",
plan_wait_inProgress = "In attesa",
plan_moveAndWait = "Muoviti e aspetta",
plan_moveAndWait_inProgress = "Muoviti e aspetta",
plan_light = "Luce",
plan_light_inProgress = "Illuminazione",
plan_extinguish = "Spegnere",
plan_extinguish_inProgress = "Estinguente",
plan_hunt = "Caccia",
plan_hunt_inProgress = "A caccia",
plan_craft = "Mestiere",
plan_craft_inProgress = "Artigianato",
plan_recruit = "Reclutare",
plan_recruit_inProgress = "Reclutamento",
plan_deconstruct = "Rimuovere",
plan_deconstruct_inProgress = "Rimozione",
plan_manageStorage = "Gestisci spazio di archiviazione",
plan_manageStorage_inProgress = "Gestione dell'archiviazione",
plan_manageSapien = "Gestisci Sapien",
plan_manageSapien_inProgress = "Gestire Sapien",
plan_addFuel = "Aggiungi carburante",
plan_addFuel_inProgress = "Aggiunta di carburante",
plan_buildPath = "Costruisci il percorso",
plan_buildPath_inProgress = "Percorso di costruzione",
plan_research = researchName,
plan_research_inProgress = researchingName,
plan_constructWith = "Uso",
plan_constructWith_inProgress = "Usando",
plan_allowUse = "Consenti l'uso",
plan_allowUse_inProgress = "Consenti l'uso",
plan_stop = "Fermare",
plan_stop_inProgress = "Fermarsi",
plan_butcher = "Macellaio",
plan_butcher_inProgress = "Macellazione",
plan_clone = "Costruire",
plan_clone_inProgress = "Costruzione",
plan_playInstrument = "Giocare a",
plan_playInstrument_inProgress = "Giocando",
								
--research
research_fire = researchName,
research_fire_inProgress = researchingName,
research_fire_description = "La tua tribù ha scoperto che il calore viene generato dall'attrito quando strofini due bastoncini insieme. Se fa abbastanza caldo, si può produrre una brace per accendere un fuoco, fornendo calore e luce.",
research_thatchBuilding = researchName,
research_thatchBuilding_inProgress = researchingName,
research_thatchBuilding_description = "La tua tribù ha scoperto che quando la vegetazione secca è allineata e posizionata su una struttura di supporto, può fornire un riparo a tenuta d'acqua.",
research_mudBrickBuilding = researchName,
research_mudBrickBuilding_inProgress = researchingName,
research_mudBrickBuilding_description = "L'argilla essiccata se mescolata con un legante come fieno o sabbia può produrre un materiale duro e durevole. La tua tribù ha scoperto che può essere adatto per costruire strutture.",
research_brickBuilding = researchName,
research_brickBuilding_inProgress = researchingName,
research_brickBuilding_description = "Ora che la tua tribù ha capito come legare insieme i mattoni cotti, ha una nuova alternativa decorativa ai mattoni di fango per costruire muri.",
research_woodBuilding = researchName,
research_woodBuilding_inProgress = researchingName,
research_woodBuilding_description = "Dividendo i tronchi con strumenti semplici, la tua tribù ha trovato un nuovo materiale da costruzione. Le strutture costruite in legno sono più robuste e resistenti alle intemperie.",
research_rockKnapping = researchName,
research_rockKnapping_inProgress = researchingName,
research_rockKnapping_description = "Usando una roccia per colpirne un'altra, la tua tribù ha scoperto che i bordi possono essere affilati e possono essere realizzati alcuni strumenti molto utili.",
research_flintKnapping = researchName,
research_flintKnapping_inProgress = researchingName,
research_flintKnapping_description = "Dopo aver trovato un nuovo tipo di roccia, la tua tribù ha provato a colpirlo per creare un nuovo bordo più nitido. Questo nuovo materiale è anche più resistente.",
research_pottery = researchName,
research_pottery_inProgress = researchingName,
research_pottery_description = "La tua tribù ha scoperto che alcuni tipi di terra possono essere pressati in forme quando sono morbidi e bagnati, e manterranno la loro forma quando si seccano e si induriscono. Questo sarà utile per memorizzare determinate risorse.",
research_potteryFiring = researchName,
research_potteryFiring_inProgress = researchingName,
research_potteryFiring_description = "La tua tribù ha notato che l'argilla si indurisce quando viene riscaldata dal fuoco. Con l'aiuto di un recinto di mattoni di fango appositamente costruito, un fuoco ancora più caldo, ora possono realizzare ceramiche più resistenti all'acqua e preservare meglio il loro contenuto.",
research_spinning = researchName,
research_spinning_inProgress = researchingName,
research_spinning_description = "La tua tribù ora può creare spaghi e corde filando insieme le fibre vegetali. Ciò sarà particolarmente utile per unire le cose e creare strumenti complessi.",
research_digging = researchName,
research_digging_inProgress = researchingName,
research_digging_description = "Con la nuova conoscenza dello scavo delle rocce, le asce manuali potrebbero essere utilizzate per rimuovere più facilmente il terreno superiore, trasportarlo altrove e rivelare cosa c'è sotto.",
research_mining = researchName,
research_mining_inProgress = researchingName,
research_mining_description = "Aggiungendo una maniglia a un semplice strumento di pietra, è possibile generare una forza sufficiente per scheggiare le superfici più dure e la tua tribù ha scoperto che ora è possibile estrarre rocce.",
research_planting = researchName,
research_planting_inProgress = researchingName,
research_planting_description = "Osservando semi e piante, la tua tribù ha scoperto come controllare dove crescono le cose. Ciò renderà più facile controllare l'approvvigionamento alimentare e fornirà nuove opzioni decorative.",
research_threshing = researchName,
research_threshing_inProgress = researchingName,
research_threshing_description = "I semi di alcune erbe hanno valore nutritivo e la tua tribù ha scoperto come estrarli più facilmente.",
research_treeFelling = researchName,
research_treeFelling_inProgress = researchingName,
research_treeFelling_description = "Con un numero sufficiente di colpi con un'ascia a mano, anche gli alberi più potenti possono essere abbattuti. Ciò fornirà tronchi di legno, che bruceranno nel fuoco per molto più tempo, ma forse ci sono anche altri usi.",
research_basicHunting = researchName,
research_basicHunting_inProgress = researchingName,
research_basicHunting_description = "La tua tribù ha trovato un modo per cacciare e uccidere piccole prede, che possono fornire risorse preziose e potenzialmente cibo, una volta preparate e cucinate.",
research_spearHunting = researchName,
research_spearHunting_inProgress = researchingName,
research_spearHunting_description = "Dopo aver sperimentato vari proiettili, la tua tribù ha scoperto che combinando l'affilatura di una lama spezzata con la stabilità di volo di un bastone dritto, ora possono cacciare con molto più successo e mirare a prede più grandi.",
research_butchery = researchName,
research_butchery_inProgress = researchingName,
research_butchery_description = "La tua tribù ora ha la capacità di separare le preziose risorse contenute all'interno di una carcassa di animali. Ora possono ottenere carne cruda, anche se potresti voler dire loro di non mangiarla ancora.",
research_woodWorking = researchName,
research_woodWorking_inProgress = researchingName,
research_woodWorking_description = "La tua tribù ha scoperto che raschiando strati via da rami e tronchi, è possibile creare molti strumenti utili e materiali da costruzione.",
research_boneCarving = researchName,
research_boneCarving_inProgress = researchingName,
research_boneCarving_description = "La tua tribù ha scoperto che le ossa possono essere modellate usando un coltello per creare lame affilate o persino emettere un suono musicale.",
research_flutePlaying = researchName,
research_flutePlaying_inProgress = researchingName,
research_flutePlaying_description = "La tua tribù ha scoperto come fare musica. La musica aiuta a unire la tua tribù, aumentando la lealtà e la felicità delle persone vicine.",
research_campfireCooking = researchName,
research_campfireCooking_inProgress = researchingName,
research_campfireCooking_description = "Dopo un momento di ispirazione, la tua tribù ha scoperto che riscaldando gli ingredienti crudi nel fuoco, possono diventare più gustosi e più facili da mangiare.",
research_baking = researchName,
research_baking_inProgress = researchingName,
research_baking_description = "Finalmente, dopo molte sperimentazioni, la tua tribù può ora creare un pasto delizioso e appagante usando gli abbondanti cereali che crescono intorno a loro.",
research_toolAssembly = researchName,
research_toolAssembly_inProgress = researchingName,
research_toolAssembly_description = "Una roccia affilata può essere usata con più forza se attaccata a un manico di legno. La tua tribù ora può creare strumenti migliori e armi più formidabili.",
research_grinding = researchName,
research_grinding_inProgress = researchingName,		
research_tiling = researchName,
research_tiling_inProgress = researchingName,
research_tiling_description = "Cotturando sottili fogli di argilla, la tua tribù ha scoperto un nuovo metodo di costruzione. Le piastrelle possono essere utilizzate per costruire tetti, pavimenti e percorsi di alta qualità.",
research_unlock_butcherMammoth = "Mammut macellaio",
								
-- paths
path_dirt = "Percorso del suolo",
path_dirt_plural = "Percorsi del suolo",
path_sand = "Sentiero di sabbia",
path_sand_plural = "Sentieri di sabbia",
path_rock = "Sentiero roccioso",
path_rock_plural = "Percorsi rocciosi",
path_clay = "Via dell'argilla",
path_clay_plural = "Percorsi di argilla",
path_tile = "Percorso delle mattonelle",
path_tile_plural = "Percorsi di piastrelle",
								
-- other objects
object_campfire = "Falò",
object_campfire_plural = "Fuochi",
object_brickKiln = "Forno",
object_brickKiln_plural = "Forni",
object_torch = "Torcia",
object_torch_plural = "Torce",
object_alpacaMeatRack = "Carne di alpaca",
object_alpacaMeatRack_plural = "Carne di alpaca",
object_alpacaMeatRackCooked = "Carne di Alpaca Cotta",
object_alpacaMeatRackCooked_plural = "Carne di Alpaca Cotta",
object_dirtWallDoor = "Muro Di Sporco Con Porta",
object_dirtWallDoor_plural = "Muro Di Sporco Con Porta",
object_build_storageArea = "Deposito",
object_build_storageArea_plural = "Aree di stoccaggio",
object_aspenSplitLog = "Registro spaccato dell'Aspen",
object_aspenSplitLog_plural = "Registri spaccati dell'Aspen",
object_dirtRoof = "Tetto in terra battuta",
object_dirtRoof_plural = "Tetti in terra battuta",
object_plan_move = "Spostare",
object_plan_move_plural = "Spostare",
object_deadAlpaca = "Carcassa di alpaca",
object_deadAlpaca_plural = "Carcasse di alpaca",
object_deadMammoth = "Carcassa di mammut",
object_deadMammoth_plural = "Carcasse di mammut",
object_chickenMeatBreastCooked = "Carne Di Pollo Cotta",
object_chickenMeatBreastCooked_plural = "Carne Di Pollo Cotta",
object_build_dirtWall = "Muro di terra",
object_build_dirtWall_plural = "Muri sporchi",
object_grass = "Fieno bagnato",
object_grass_plural = "Fieno bagnato",
object_flaxDried = "Lino secco",
object_flaxDried_plural = "Lino secco",
object_splitLogFloor = "Piano in legno diviso 2x2",
object_splitLogFloor_plural = "Dividi pavimenti in tronchi 2x2",
object_splitLogFloor4x4 = "Dividi il piano di tronchi 4x4",
object_splitLogFloor4x4_plural = "Dividi pavimenti in tronchi 4x4",
object_mudBrickFloor2x2 = "Pavimento in mattoni di fango 2x2",
object_mudBrickFloor2x2_plural = "Pavimento in mattoni di fango 2x2",
object_build_mudBrickFloor2x2 = "Pavimento in mattoni di fango 2x2",
object_build_mudBrickFloor2x2_plural = "Pavimento in mattoni di fango 2x2",
object_mudBrickFloor4x4 = "Pavimento in laterizio 4x4",
object_mudBrickFloor4x4_plural = "Pavimento in laterizio 4x4",
object_build_mudBrickFloor4x4 = "Pavimento in laterizio 4x4",
object_build_mudBrickFloor4x4_plural = "Pavimento in laterizio 4x4",
object_tileFloor2x2 = "Pavimento in piastrelle 2x2",
object_tileFloor2x2_plural = "Pavimento in piastrelle 2x2s",
object_build_tileFloor2x2 = "Pavimento in piastrelle 2x2",
object_build_tileFloor2x2_plural = "Pavimento in piastrelle 2x2s",
object_tileFloor4x4 = "Pavimento in piastrelle 4x4",
object_tileFloor4x4_plural = "Pavimento in piastrelle 4x4",
object_build_tileFloor4x4 = "Pavimento in piastrelle 4x4",
object_build_tileFloor4x4_plural = "Pavimento in piastrelle 4x4",
object_splitLogWall = "Muro di tronchi diviso",
object_splitLogWall_plural = "Dividi pareti di tronchi",
object_splitLogWall4x1 = "Parete corta del ceppo diviso",
object_splitLogWall4x1_plural = "Spacca le pareti corte del ceppo",
object_splitLogWall2x2 = "Parete quadrata del ceppo diviso",
object_splitLogWall2x2_plural = "Spacca le pareti quadrate del ceppo",
object_splitLogWallDoor = "Muro Di Ceppo Diviso Con Porta",
object_splitLogWallDoor_plural = "Diviso Log Pareti Con Porte",
object_splitLogRoofEnd = "Parete del tetto in legno diviso",
object_splitLogRoofEnd_plural = "Dividi le pareti del tetto in tronchi",
object_splitLogSteps = "Dividi Log Passi 2x3 Piano Singolo",
object_splitLogSteps_plural = "Dividi Log Passi 2x3 Piano Singolo",
object_splitLogSteps2x2 = "Dividi i passaggi del registro 2x2 a metà piano",
object_splitLogSteps2x2_plural = "Dividi i passaggi del registro 2x2 a metà piano",
object_stick = "Bastone",
object_stick_plural = "Bastoni",
object_build_thatchRoof = "Tetto di paglia",
object_build_thatchRoof_plural = "Tetti di paglia",
object_build_thatchRoofLarge = "Grande tetto di paglia",
object_build_thatchRoofLarge_plural = "Grandi tetti di paglia",
object_build_thatchRoofLargeCorner = "Ampio angolo del tetto di paglia",
object_build_thatchRoofLargeCorner_plural = "Grandi angoli del tetto di paglia",
object_build_tileRoof = "Capanna/tetto di tegole",
object_build_tileRoof_plural = "Tetti di tegole",
object_dirtWall = "Muro di terra",
object_dirtWall_plural = "Muri sporchi",
object_alpacaWoolskin = "Pelle di lana d'alpaca",
object_alpacaWoolskin_plural = "Pelli di lana d'alpaca",
object_mammothWoolskin = "Pelle di lana di mammut",
object_mammothWoolskin_plural = "Mammut Woolskin",
object_bone = "Osso",
object_bone_plural = "Ossa",
object_rock = "Roccia normale",
object_rock_plural = "Rocce semplici",
object_rockSmall = "Piccola Roccia",
object_rockSmall_plural = "Piccole rocce",
object_rockLarge = "Masso",
object_rockLarge_plural = "massi",
object_limestoneRock = "Roccia calcarea",
object_limestoneRock_plural = "Rocce Calcaree",
object_limestoneRockSmall = "Piccola roccia calcarea",
object_limestoneRockSmall_plural = "Piccole rocce calcaree",
object_limestoneRockLarge = "Masso calcareo",
object_limestoneRockLarge_plural = "Massi calcarei",
object_redRock = "roccia rossa",
object_redRock_plural = "Rocce Rosse",
object_redRockSmall = "Piccola Roccia Rossa",
object_redRockSmall_plural = "Piccole rocce rosse",
object_redRockLarge = "Masso di roccia rossa",
object_redRockLarge_plural = "massi di roccia rossa",
object_greenRock = "Pietraverde",
object_greenRock_plural = "Rocce di pietra verde",
object_greenRockSmall = "Piccola roccia di Greenstone",
object_greenRockSmall_plural = "Piccole rocce di Greenstone",
object_greenRockLarge = "Pietraverde Boulder",
object_greenRockLarge_plural = "massi di pietra verde",
object_chickenMeatBreast = "Carne di gallina",
object_chickenMeatBreast_plural = "Carne di gallina",
object_birchWoodenPole = "Palo in legno di betulla",
object_birchWoodenPole_plural = "Pali in legno di betulla",
object_willowWoodenPole = "Palo in legno di salice",
object_willowWoodenPole_plural = "Pali di legno di salice",
object_appleWoodenPole = "Palo in legno di mela",
object_appleWoodenPole_plural = "Pali di legno di mela",
object_orangeWoodenPole = "Palo di legno arancione",
object_orangeWoodenPole_plural = "Pali di legno arancioni",
object_peachWoodenPole = "Palo in legno di pesca",
object_peachWoodenPole_plural = "Pali in legno di pesca",
object_bambooWoodenPole = "Palo in legno di bambù",
object_bambooWoodenPole_plural = "Pali di legno di bambù",
object_thatchWallDoor = "Muro Di Paglia Con Porta",
object_thatchWallDoor_plural = "Pareti Di Paglia Con Porta",
object_birchSplitLog = "Tronco diviso in betulla",
object_birchSplitLog_plural = "Tronchi di betulla spaccati",
object_willowSplitLog = "Tronco diviso in salice",
object_willowSplitLog_plural = "Tronchi spaccati di salice",
object_appleSplitLog = "Registro diviso Apple",
object_appleSplitLog_plural = "Registri divisi di Apple",
object_orangeSplitLog = "Registro di divisione arancione",
object_orangeSplitLog_plural = "Registri divisi arancioni",
object_peachSplitLog = "Registro diviso pesca",
object_peachSplitLog_plural = "Registri divisi della pesca",
object_coconutSplitLog = "Registro spaccato di cocco",
object_coconutSplitLog_plural = "Registri spaccati di cocco",
object_build_hayBed = "Letto di fieno",
object_build_hayBed_plural = "letti di fieno",
object_build_woolskinBed = "Letto in lana",
object_build_woolskinBed_plural = "Letti in lana",
object_aspenWoodenPole = "Palo di legno di pioppo tremulo",
object_aspenWoodenPole_plural = "Pali di legno di pioppo tremulo",
object_chicken = "Pollo",
object_chicken_plural = "Polli",
object_chickenMeat = "Carne di gallina",
object_chickenMeat_plural = "Carne di gallina",
object_build_splitLogFloor = "Piano in legno diviso 2x2",
object_build_splitLogFloor_plural = "Dividi pavimenti in tronchi 2x2",
object_build_splitLogFloor4x4 = "Dividi il piano di tronchi 4x4",
object_build_splitLogFloor4x4_plural = "Dividi pavimenti in tronchi 4x4",
object_build_splitLogWall = "Muro di tronchi diviso",
object_build_splitLogWall_plural = "Dividi pareti di tronchi",
object_build_splitLogWall4x1 = "Parete corta del ceppo diviso",
object_build_splitLogWall4x1_plural = "Spacca le pareti corte del ceppo",
object_build_splitLogWall2x2 = "Parete quadrata del ceppo diviso",
object_build_splitLogWall2x2_plural = "Spacca le pareti quadrate del ceppo",
object_build_splitLogRoofEnd = "Parete del tetto in legno diviso",
object_build_splitLogRoofEnd_plural = "Dividi le pareti del tetto in tronchi",
object_build_splitLogWallDoor = "Muro Di Ceppo Diviso Con Porta",
object_build_splitLogWallDoor_plural = "Diviso Log Pareti Con Porte",
object_build_splitLogSteps = "Dividi Log Passi 2x3 Piano Singolo",
object_build_splitLogSteps_plural = "Dividi Log Passi 2x3 Piano Singolo",
object_build_splitLogSteps2x2 = "Dividi i passaggi del registro 2x2 a metà piano",
object_build_splitLogSteps2x2_plural = "Dividi i passaggi del registro 2x2 a metà piano",
object_build_splitLogRoof = "Tetto diviso in tronchi",
object_build_splitLogRoof_plural = "Tetti di tronchi spaccati",
object_mammoth = "Mammut",
object_mammoth_plural = "Mammut",
object_build_dirtRoof = "Tetto in terra battuta",
object_build_dirtRoof_plural = "Tetti in terra battuta",
object_flint = "pietra focaia",
object_flint_plural = "pietra focaia",
object_clay = "Argilla",
object_clay_plural = "Argilla",
object_build_craftArea = "Area artigianale",
object_build_craftArea_plural = "Aree di lavorazione",
object_build_dirtWallDoor = "Muro Di Sporco Con Porta",
object_build_dirtWallDoor_plural = "Muro Di Sporco Con Porta",
object_stoneKnife = "Coltello di pietra",
object_stoneKnife_plural = "Coltelli di pietra",
object_stoneKnife_limestone = "Coltello per calcare",
object_stoneKnife_limestone_plural = "Coltelli di calcare",
object_stoneKnife_redRock = "Coltello Roccia Rossa",
object_stoneKnife_redRock_plural = "Coltelli di roccia rossa",
object_stoneKnife_greenRock = "Coltello Pietraverde",
object_stoneKnife_greenRock_plural = "Coltelli di pietra verde",
object_flintKnife = "Coltello di selce",
object_flintKnife_plural = "Coltelli di selce",
object_boneKnife = "Coltello d'osso",
object_boneKnife_plural = "Coltelli d'osso",
object_boneFlute = "Flauto d'osso",
object_boneFlute_plural = "Flauti d'osso",
object_logDrum = "Log tamburo",
object_logDrum_plural = "Log tamburi",
object_balafon = "Balafon",
object_balafon_plural = "Balafons",
object_drumStick = "Bacchette",
object_drumStick_plural = "Bacchette",
object_alpaca = "Alpaca",
object_alpaca_plural = "Alpaca",
object_storageArea = "Deposito",
object_storageArea_plural = "Aree di stoccaggio",
object_stoneAxeHead = "Ascia di pietra",
object_stoneAxeHead_plural = "Asce in pietra",
object_stoneAxeHead_limestone = "Ascia a mano in pietra calcarea",
object_stoneAxeHead_limestone_plural = "Asce manuali in pietra calcarea",
object_stoneAxeHead_redRock = "Ascia a mano di roccia rossa",
object_stoneAxeHead_redRock_plural = "Asce a mano Red Rock",
object_stoneAxeHead_greenRock = "Ascia a mano di pietra verde",
object_stoneAxeHead_greenRock_plural = "Asce a mano Greenstone",
object_flintAxeHead = "Ascia a mano in selce",
object_flintAxeHead_plural = "Asce a mano in selce",
object_chickenMeatCooked = "Carne Di Pollo Cotta",
object_chickenMeatCooked_plural = "Carne Di Pollo Cotta",
object_pumpkinCooked = "Zucca arrosto",
object_pumpkinCooked_plural = "Zucche Arrosto",
object_beetrootCooked = "Barbabietola Arrostita",
object_beetrootCooked_plural = "Barbabietole Arrosto",
object_flatbread = "Focaccia",
object_flatbread_plural = "Focacce",
object_flatbreadRotten = "Focaccia ammuffita",
object_flatbreadRotten_plural = "Focacce ammuffite",
object_build_thatchWall = "Muro di paglia",
object_build_thatchWall_plural = "Muri di paglia",
object_build_thatchWallLargeWindow = "Muro Di Paglia Con Finestra Singola",
object_build_thatchWallLargeWindow_plural = "Muro Di Paglia Con Finestre Singole",
object_build_thatchWall4x1 = "Muro corto di paglia",
object_build_thatchWall4x1_plural = "Muri corti di paglia",
object_build_thatchWall2x2 = "Muro quadrato di paglia",
object_build_thatchWall2x2_plural = "Pareti quadrate di paglia",
object_build_thatchRoofEnd = "Parete del tetto di paglia",
object_build_thatchRoofEnd_plural = "Pareti del tetto di paglia",
object_deadChicken = "Carcassa di pollo",
object_deadChicken_plural = "Carcasse di pollo",
object_deadChickenRotten = "Carcassa di pollo marcia",
object_deadChickenRotten_plural = "Carcasse di pollo marce",
object_thatchWall = "Muro di paglia",
object_thatchWall_plural = "Muri di paglia",
object_thatchWallLargeWindow = "Muro Di Paglia Con Finestra Singola",
object_thatchWallLargeWindow_plural = "Muro Di Paglia Con Finestre Singole",
object_thatchWall4x1 = "Muro corto di paglia",
object_thatchWall4x1_plural = "Muri corti di paglia",
object_thatchWall2x2 = "Muro quadrato di paglia",
object_thatchWall2x2_plural = "Pareti quadrate di paglia",
object_thatchRoofEnd = "Parete del tetto di paglia",
object_thatchRoofEnd_plural = "Pareti del tetto di paglia",
object_sand = "Sabbia",
object_sand_plural = "Sabbia",
object_craftArea = "Area artigianale",
object_craftArea_plural = "Aree di lavorazione",
object_build_campfire = "Falò",
object_build_campfire_plural = "Fuochi",
object_build_brickKiln = "Forno",
object_build_brickKiln_plural = "Forni",
object_build_torch = "Torcia",
object_build_torch_plural = "Torce",
object_stoneSpear = "Lancia di pietra",
object_stoneSpear_plural = "Lance di pietra",
object_flintSpear = "Lancia di selce",
object_flintSpear_plural = "Lance di selce",
object_boneSpear = "Lancia d'ossa",
object_boneSpear_plural = "Lance d'osso",
object_stonePickaxe = "Piccone di pietra",
object_stonePickaxe_plural = "Picconi di pietra",
object_flintPickaxe = "Piccone di selce",
object_flintPickaxe_plural = "Picconi di selce",
object_stoneHatchet = "Ascia di pietra",
object_stoneHatchet_plural = "Asce di pietra",
object_flintHatchet = "Ascia di selce",
object_flintHatchet_plural = "Asce di selce",
object_alpacaMeatLeg = "Carne di alpaca",
object_alpacaMeatLeg_plural = "Carne di alpaca",
object_alpacaMeatLegCooked = "Carne di Alpaca Cotta",
object_alpacaMeatLegCooked_plural = "Carne di Alpaca Cotta",
object_hayBed = "Letto di fieno",
object_hayBed_plural = "letti di fieno",
object_woolskinBed = "Letto in lana",
object_woolskinBed_plural = "Letti in lana",
object_sapien = "Sapien",
object_sapien_plural = "Sapiens",
object_thatchRoof = "Tetto di paglia",
object_thatchRoof_plural = "Tetti di paglia",
object_thatchRoofLarge = "Grande tetto di paglia",
object_thatchRoofLarge_plural = "Grandi tetti di paglia",
object_thatchRoofLargeCorner = "Ampio angolo del tetto di paglia",
object_thatchRoofLargeCorner_plural = "Grandi angoli del tetto di paglia",
object_tileRoof = "Capanna/tetto di tegole",
object_tileRoof_plural = "Tetti di tegole",
object_pineWoodenPole = "Palo in legno di pino",
object_pineWoodenPole_plural = "Pali in legno di pino",
object_hay = "Fieno",
object_hay_plural = "Fieno",
object_hayRotten = "Fieno Marcio",
object_hayRotten_plural = "Fieno Marcio",
object_terrainModificationProxy = "Modifica terreno",
object_terrainModificationProxy_plural = "Modifica terreno",
object_dirt = "Suolo",
object_dirt_plural = "Suolo",
object_richDirt = "Suolo fertile",
object_richDirt_plural = "Suolo fertile",
object_poorDirt = "Terreno povero",
object_poorDirt_plural = "Terreno povero",
object_riverSand = "Sabbia di fiume",
object_riverSand_plural = "Sabbia di fiume",
object_redSand = "Sabbia Rossa",
object_redSand_plural = "Sabbia Rossa",
object_stoneSpearHead = "Testa di lancia di pietra",
object_stoneSpearHead_plural = "Punte di lancia di pietra",
object_stoneSpearHead_limestone = "Testa di lancia in pietra calcarea",
object_stoneSpearHead_limestone_plural = "Punte di lancia di calcare",
object_stoneSpearHead_redRock = "Testa di lancia di roccia rossa",
object_stoneSpearHead_redRock_plural = "Punte di lancia Red Rock",
object_stoneSpearHead_greenRock = "Testa di lancia di pietra verde",
object_stoneSpearHead_greenRock_plural = "Punte di lancia di Greenstone",
object_stonePickaxeHead = "Testa di piccone di pietra",
object_stonePickaxeHead_plural = "Teste di piccone di pietra",
object_stonePickaxeHead_limestone = "Testa di piccone di calcare",
object_stonePickaxeHead_limestone_plural = "Teste di piccone calcaree",
object_stonePickaxeHead_redRock = "Testa di piccone Red Rock",
object_stonePickaxeHead_redRock_plural = "Teste di piccone Red Rock",
object_stonePickaxeHead_greenRock = "Testa di piccone Greenstone",
object_stonePickaxeHead_greenRock_plural = "Teste di piccone Greenstone",
object_flintSpearHead = "Testa di lancia di selce",
object_flintSpearHead_plural = "Punte di lancia di selce",
object_boneSpearHead = "Testa di lancia in osso",
object_boneSpearHead_plural = "Punte di lancia in osso",
object_flintPickaxeHead = "Testa di piccone di selce",
object_flintPickaxeHead_plural = "Teste di piccone di selce",
object_build_thatchWallDoor = "Muro Di Paglia Con Porta",
object_build_thatchWallDoor_plural = "Muro Di Paglia Con Porta",
object_pineSplitLog = "Tronco di pino diviso",
object_pineSplitLog_plural = "Tronchi di pino spaccati",
object_burntBranch = "Ramo bruciato",
object_burntBranch_plural = "Rami bruciati",
object_unfiredUrnWet = "Urna cruda (bagnata)",
object_unfiredUrnWet_plural = "Urne crude (umide)",
object_unfiredUrnDry = "Urna non cotta",
object_unfiredUrnDry_plural = "Urne crude",
object_firedUrn = "Urna licenziata",
object_firedUrn_plural = "Urne cotte",
object_unfiredUrnHulledWheat = "Grano decorticato (urna cruda)",
object_unfiredUrnHulledWheat_plural = "Grano decorticato (urna cruda)",
object_unfiredUrnHulledWheatRotten = "Grano decorticato ammuffito (urna cruda)",
object_unfiredUrnHulledWheatRotten_plural = "Grano decorticato ammuffito (urna cruda)",
object_firedUrnHulledWheat = "Grano decorticato (urna cotta)",
object_firedUrnHulledWheat_plural = "Grano decorticato (urna cotta)",
object_firedUrnHulledWheatRotten = "Grano decorticato ammuffito (urna cotta)",
object_firedUrnHulledWheatRotten_plural = "Grano decorticato ammuffito (urna cotta)",
object_temporaryCraftArea = "Mestiere",
object_temporaryCraftArea_plural = "Mestiere",
object_quernstone = "Quern-pietra",
object_quernstone_plural = "Quern-pietre",
object_quernstone_limestone = "Quern-pietra",
object_quernstone_limestone_plural = "Quern-pietre",
object_quernstone_redRock = "Quern-pietra",
object_quernstone_redRock_plural = "Quern-pietre",
object_quernstone_greenRock = "Quern-pietra",
object_quernstone_greenRock_plural = "Quern-pietre",
object_unfiredUrnFlour = "Farina (urna cruda)",
object_unfiredUrnFlour_plural = "Farina (Urne Crude)",
object_unfiredUrnFlourRotten = "Farina ammuffita (urna cruda)",
object_unfiredUrnFlourRotten_plural = "Farina Ammuffita (Urne Crude)",
object_firedUrnFlour = "Farina (Urna Cotta)",
object_firedUrnFlour_plural = "Farina (Urne Cotte)",
object_firedUrnFlourRotten = "Farina Ammuffita (Urna Cotta)",
object_firedUrnFlourRotten_plural = "Farina Ammuffita (Urne Cotte)",
object_splitLogBench = "Banco di tronchi spaccati",
object_splitLogBench_plural = "Panche di tronchi divisi",
object_build_splitLogBench = "Banco di tronchi spaccati",
object_build_splitLogBench_plural = "Panche di tronchi divisi",
object_splitLogRoof = "Tetto diviso in tronchi",
object_splitLogRoof_plural = "Tetti di tronchi spaccati",
object_branchRotten = "Ramo marcio",
object_branchRotten_plural = "Rami marci",
object_breadDough = "Impasto Di Pane",
object_breadDough_plural = "Impasto Di Pane",
object_breadDoughRotten = "Impasto Di Pane Marcio",
object_breadDoughRotten_plural = "Impasto Di Pane Marcio",
object_flaxTwine = "Spago di lino",
object_flaxTwine_plural = "Spago di lino",
object_mudBrickWet_sand = "Mattone di fango di sabbia (bagnato)",
object_mudBrickWet_sand_plural = "Mattoni di fango di sabbia (bagnati)",
object_mudBrickWet_hay = "Mattone di fango di fieno (bagnato)",
object_mudBrickWet_hay_plural = "Mattoni di fango di fieno (bagnati)",
object_mudBrickWet_riverSand = "Mattone di fango di sabbia di fiume (bagnato)",
object_mudBrickWet_riverSand_plural = "Mattoni di fango di sabbia di fiume (bagnati)",
object_mudBrickWet_redSand = "Mattone di fango di sabbia rossa (bagnato)",
object_mudBrickWet_redSand_plural = "Mattoni di fango di sabbia rossa (bagnati)",
object_mudTileWet = "Piastrella cruda (bagnata)",
object_mudTileWet_plural = "Piastrelle crude (bagnate)",
object_mudTileDry = "Piastrella cruda",
object_mudTileDry_plural = "Piastrelle crude",
object_firedTile = "Piastrella",
object_firedTile_plural = "Piastrelle",
object_mudBrickDry_sand = "Mattone di fango di sabbia (a secco)",
object_mudBrickDry_sand_plural = "Mattoni di fango di sabbia (a secco)",
object_mudBrickDry_hay = "Mattone di fango di fieno (a secco)",
object_mudBrickDry_hay_plural = "Mattoni di fango di fieno (a secco)",
object_mudBrickDry_riverSand = "Mattone di fango di sabbia di fiume (a secco)",
object_mudBrickDry_riverSand_plural = "Mattoni di fango di sabbia di fiume (a secco)",
object_mudBrickDry_redSand = "Mattone di fango di sabbia rossa (a secco)",
object_mudBrickDry_redSand_plural = "Mattoni di fango di sabbia rossa (a secco)",
object_firedBrick_sand = "Mattone di sabbia cotto",
object_firedBrick_sand_plural = "Mattoni di sabbia cotti",
object_firedBrick_hay = "Mattone di fieno licenziato",
object_firedBrick_hay_plural = "Mattoni di fieno cotti",
object_firedBrick_riverSand = "Mattone di sabbia di fiume licenziato",
object_firedBrick_riverSand_plural = "Mattoni di sabbia di fiume licenziati",
object_firedBrick_redSand = "Mattone di sabbia rosso infornato",
object_firedBrick_redSand_plural = "Mattoni di sabbia rossi cotti",
object_mudBrickWall = "Muro di mattoni di fango",
object_mudBrickWall_plural = "Muri di mattoni di fango",
object_mudBrickWall4x1 = "Muretto di mattoni di fango",
object_mudBrickWall4x1_plural = "Muri corti di mattoni di fango",
object_mudBrickWall2x2 = "Muro quadrato di mattoni di fango",
object_mudBrickWall2x2_plural = "Muri quadrati di mattoni di fango",
object_build_mudBrickWall = "Muro di mattoni di fango",
object_build_mudBrickWall_plural = "Muri di mattoni di fango",
object_build_mudBrickWall4x1 = "Muretto di mattoni di fango",
object_build_mudBrickWall4x1_plural = "Muri corti di mattoni di fango",
object_build_mudBrickWall2x2 = "Muro quadrato di mattoni di fango",
object_build_mudBrickWall2x2_plural = "Muri quadrati di mattoni di fango",
object_mudBrickWallDoor = "Muro Di Mattoni Con Porta",
object_mudBrickWallDoor_plural = "Muro Di Mattoni Con Porta",
object_build_mudBrickWallDoor = "Muro Di Mattoni Con Porta",
object_build_mudBrickWallDoor_plural = "Muro Di Mattoni Con Porta",
object_mudBrickWallLargeWindow = "Muro Di Mattoni Con Grande Finestra",
object_mudBrickWallLargeWindow_plural = "Muro Di Mattoni Con Grande Finestra",
object_build_mudBrickWallLargeWindow = "Muro Di Mattoni Con Grande Finestra",
object_build_mudBrickWallLargeWindow_plural = "Muro Di Mattoni Con Grande Finestra",
object_mudBrickColumn = "Colonna di fango",
object_mudBrickColumn_plural = "Colonne di fango",
object_build_mudBrickColumn = "Colonna di fango",
object_build_mudBrickColumn_plural = "Colonne di fango",
object_brickWall = "Muro di mattoni",
object_brickWall_plural = "Muri di mattoni",
object_build_brickWall = "Muro di mattoni",
object_build_brickWall_plural = "Muri di mattoni",
object_brickWallDoor = "Muro Di Mattoni Con Porta",
object_brickWallDoor_plural = "Muro Di Mattoni Con Porta",
object_build_brickWallDoor = "Muro Di Mattoni Con Porta",
object_build_brickWallDoor_plural = "Muro Di Mattoni Con Porta",
object_brickWallLargeWindow = "Muro Di Mattoni Con Grande Finestra",
object_brickWallLargeWindow_plural = "Muro Di Mattoni Con Grande Finestra",
object_build_brickWallLargeWindow = "Muro Di Mattoni Con Grande Finestra",
object_build_brickWallLargeWindow_plural = "Muro Di Mattoni Con Grande Finestra",
object_brickWall4x1 = "Muro corto in mattoni",
object_brickWall4x1_plural = "Muri corti in mattoni",
object_build_brickWall4x1 = "Muro corto in mattoni",
object_build_brickWall4x1_plural = "Muri corti in mattoni",
object_brickWall2x2 = "Muro quadrato di mattoni",
object_brickWall2x2_plural = "Muri quadrati di mattoni",
object_build_brickWall2x2 = "Muro quadrato di mattoni",
object_build_brickWall2x2_plural = "Muri quadrati di mattoni",
object_splitLogWallLargeWindow = "Muro Di Tronchi Diviso Con Ampia Finestra",
object_splitLogWallLargeWindow_plural = "Muro Di Tronchi Diviso Con Ampia Finestra",
object_build_splitLogWallLargeWindow = "Muro Di Tronchi Diviso Con Ampia Finestra",
object_build_splitLogWallLargeWindow_plural = "Muro Di Tronchi Diviso Con Ampia Finestra",
object_mammothMeat = "Carne di mammut",
object_mammothMeat_plural = "Carne di mammut",
object_mammothMeatTBone = "Carne di mammut",
object_mammothMeatTBone_plural = "Carne di mammut",
object_mammothMeatCooked = "Carne di mammut cotta",
object_mammothMeatCooked_plural = "Carne di mammut cotta",
object_mammothMeatTBoneCooked = "Carne di mammut cotta",
object_mammothMeatTBoneCooked_plural = "Carne di mammut cotta",
								
--order
order_idle = "Oziare",
order_resting = "Riposo",
order_multitask_social = "Sociale",
order_multitask_social_inProgress = "Socializzare",
order_multitask_lookAt = "Aspetto",
order_multitask_lookAt_inProgress = "Guardare",
order_gather = "Mettere insieme",
order_gather_inProgress = "Raccolta",
order_chop = "Taglio",
order_chop_inProgress = "Tritare",
order_storeObject = "Negozio",
order_storeObject_inProgress = "Memorizzazione",
order_transferObject = "Trasferimento",
order_transferObject_inProgress = "Trasferimento",
order_destroyContents = "Distruggi contenuti",
order_destroyContents_inProgress = "Contenuti distruttivi",
order_pullOut = "Tira fuori",
order_pullOut_inProgress = "Tirando fuori",
order_moveTo = "Spostare",
order_moveTo_inProgress = "In movimento",
order_moveToLogistics = "Trasferimento",
order_moveToLogistics_inProgress = "Trasferimento",
order_flee = "Fuggire",
order_flee_inProgress = "Fuggendo",
order_sneakTo = "Sgattaiolare",
order_sneakTo_inProgress = "furtivamente",
order_pickupObject = "Andare a prendere",
order_pickupObject_inProgress = "Recupero",
order_deliver = "Consegnare",
order_deliver_inProgress = "Consegnare",
order_removeObject = "Chiaro",
order_removeObject_inProgress = "Cancellazione",
order_buildMoveComponent = "Costruire",
order_buildMoveComponent_inProgress = "Costruzione",
order_buildActionSequence = "Costruire",
order_buildActionSequence_inProgress = "Costruzione",
order_eat = "Mangiare",
order_eat_inProgress = "Mangiare",
order_dig = "Scavare",
order_dig_inProgress = "Scavando",
order_mine = "Il mio",
order_mine_inProgress = "Estrazione",
order_clear = "Chiaro",
order_clear_inProgress = "Cancellazione",
order_follow = "Seguire",
order_follow_inProgress = "Seguente",
order_social = "Sociale",
order_social_inProgress = "Socializzare",
order_turn = "Giro",
order_turn_inProgress = "Girando",
order_fall = "Autunno",
order_fall_inProgress = "Cadente",
order_dropObject = "Far cadere",
order_dropObject_inProgress = "Cadendo",
order_sleep = "Sonno",
order_sleep_inProgress = "Dormire",
order_light = "Luce",
order_light_inProgress = "Illuminazione",
order_extinguish = "Spegnere",
order_extinguish_inProgress = "Estinguente",
order_throwProjectile = "Caccia",
order_throwProjectile_inProgress = "A caccia",
order_craft = "Mestiere",
order_craft_inProgress = "Artigianato",
order_recruit = "Reclutare",
order_recruit_inProgress = "Reclutamento",
order_sit = "Sedersi",
order_sit_inProgress = "Seduta",
order_playInstrument = "Giocare a",
order_playInstrument_inProgress = "Giocando",
order_butcher = "Macellaio",
order_butcher_inProgress = "Macellazione",
order_putOnClothing = "Indossare i vestiti",
order_putOnClothing_inProgress = "Indossare abiti",
order_takeOffClothing = "Togliti i vestiti",
order_takeOffClothing_inProgress = "Togliersi i vestiti",
								
--resource
resource_branch = "Ramo",
resource_branch_plural = "Rami",
resource_burntBranch = "Ramo bruciato",
resource_burntBranch_plural = "Rami bruciati",
resource_log = "Tronco d'albero",
resource_log_plural = "Registri",
resource_rock = "Grande Roccia",
resource_rock_plural = "Grandi rocce",
resource_dirt = "Suolo",
resource_dirt_plural = "Suolo",
resource_hay = "Fieno",
resource_hay_plural = "Fieno",
resource_hayRotten = "Fieno Marcio",
resource_hayRotten_plural = "Fieno Marcio",
resource_grass = "Fieno bagnato",
resource_grass_plural = "Fieno bagnato",
resource_flaxDried = "Lino secco",
resource_flaxDried_plural = "Lino secco",
resource_sand = "Sabbia",
resource_sand_plural = "Sabbia",
resource_rockSmall = "Piccola Roccia",
resource_rockSmall_plural = "Piccole rocce",
resource_flint = "pietra focaia",
resource_flint_plural = "pietra focaia",
resource_clay = "Argilla",
resource_clay_plural = "Argilla",
resource_deadChicken = "Carcassa di pollo",
resource_deadChicken_plural = "Carcasse di pollo",
resource_deadChickenRotten = "Carcassa di pollo marcia",
resource_deadChickenRotten_plural = "Carcasse di pollo marce",
resource_deadAlpaca = "Carcassa di alpaca",
resource_deadAlpaca_plural = "Carcasse di alpaca",
resource_chickenMeat = "Carne di gallina",
resource_chickenMeat_plural = "Carne di gallina",
resource_chickenMeatCooked = "Carne Di Pollo Cotta",
resource_chickenMeatCooked_plural = "Carne Di Pollo Cotta",
resource_pumpkinCooked = "Zucca arrosto",
resource_pumpkinCooked_plural = "Zucche Arrosto",
resource_beetrootCooked = "Barbabietola Arrostita",
resource_beetrootCooked_plural = "Barbabietole Arrosto",
resource_flatbread = "Focaccia",
resource_flatbread_plural = "Focacce",
resource_flatbreadRotten = "Focaccia ammuffita",
resource_flatbreadRotten_plural = "Focacce ammuffite",
resource_alpacaMeat = "Carne di alpaca",
resource_alpacaMeat_plural = "Carne di alpaca",
resource_alpacaMeatCooked = "Carne di Alpaca Cotta",
resource_alpacaMeatCooked_plural = "Carne di Alpaca Cotta",
resource_stoneSpear = "Lancia di pietra",
resource_stoneSpear_plural = "Lance di pietra",
resource_stoneSpearHead = "Testa di lancia di pietra",
resource_stoneSpearHead_plural = "Punte di lancia di pietra",
resource_stonePickaxe = "Piccone di pietra",
resource_stonePickaxe_plural = "Picconi di pietra",
resource_stonePickaxeHead = "Testa di piccone di pietra",
resource_stonePickaxeHead_plural = "Teste di piccone di pietra",
resource_stoneHatchet = "Ascia di pietra",
resource_stoneHatchet_plural = "Asce di pietra",
resource_stoneAxeHead = "Testa di ascia di pietra",
resource_stoneAxeHead_plural = "Teste di ascia di pietra",
resource_stoneKnife = "Coltello di pietra",
resource_stoneKnife_plural = "Coltelli di pietra",
resource_flintSpear = "Lancia di selce",
resource_flintSpear_plural = "Lance di selce",
resource_boneSpear = "Lancia d'ossa",
resource_boneSpear_plural = "Lance d'osso",
resource_flintPickaxe = "Piccone di selce",
resource_flintPickaxe_plural = "Picconi di selce",
resource_flintHatchet = "Ascia di selce",
resource_flintHatchet_plural = "Asce di selce",
resource_flintSpearHead = "Testa di lancia di selce",
resource_flintSpearHead_plural = "Punte di lancia di selce",
resource_boneSpearHead = "Testa di lancia in osso",
resource_boneSpearHead_plural = "Punte di lancia in osso",
resource_flintPickaxeHead = "Testa di piccone di selce",
resource_flintPickaxeHead_plural = "Teste di piccone di selce",
resource_flintAxeHead = "Testa d'ascia di selce",
resource_flintAxeHead_plural = "Teste di ascia di selce",
resource_flintKnife = "Coltello di pietra",
resource_flintKnife_plural = "Coltelli di pietra",
resource_boneKnife = "Coltello d'osso",
resource_boneKnife_plural = "Coltelli d'osso",
resource_boneFlute = "Flauto d'osso",
resource_boneFlute_plural = "Flauti d'osso",
resource_logDrum = "Log tamburo",
resource_logDrum_plural = "Log tamburi",
resource_balafon = "Balafon",
resource_balafon_plural = "Balafons",
resource_woodenPole = "Palo di legno",
resource_woodenPole_plural = "Pali di legno",
resource_splitLog = "Registro diviso",
resource_splitLog_plural = "Registri divisi",
resource_woolskin = "Pelle di lana",
resource_woolskin_plural = "Pelli di lana",
resource_bone = "Osso",
resource_bone_plural = "Ossa",
resource_unfiredUrnWet = "Urna cruda (bagnata)",
resource_unfiredUrnWet_plural = "Urne crude (umide)",
resource_unfiredUrnDry = "Urna non cotta",
resource_unfiredUrnDry_plural = "Urne crude",
resource_firedUrn = "Urna licenziata",
resource_firedUrn_plural = "Urne cotte",
resource_unfiredUrnHulledWheat = "Grano decorticato (urna cruda)",
resource_unfiredUrnHulledWheat_plural = "Grano decorticato (urna cruda)",
resource_unfiredUrnHulledWheatRotten = "Grano decorticato ammuffito (urna cruda)",
resource_unfiredUrnHulledWheatRotten_plural = "Grano decorticato ammuffito (urna cruda)",
resource_firedUrnHulledWheat = "Grano decorticato (urna cotta)",
resource_firedUrnHulledWheat_plural = "Grano decorticato (urna cotta)",
resource_firedUrnHulledWheatRotten = "Grano decorticato ammuffito (urna cotta)",
resource_firedUrnHulledWheatRotten_plural = "Grano decorticato ammuffito (urna cotta)",
resource_quernstone = "Quern-pietra",
resource_quernstone_plural = "Quern-pietre",
resource_unfiredUrnFlour = "Farina (urna cruda)",
resource_unfiredUrnFlour_plural = "Farina (urna cruda)",
resource_unfiredUrnFlourRotten = "Farina ammuffita (urna cruda)",
resource_unfiredUrnFlourRotten_plural = "Farina ammuffita (urna cruda)",
resource_firedUrnFlour = "Farina (Urna Cotta)",
resource_firedUrnFlour_plural = "Farina (Urna Cotta)",
resource_firedUrnFlourRotten = "Farina Ammuffita (Urna Cotta)",
resource_firedUrnFlourRotten_plural = "Farina Ammuffita (Urna Cotta)",
resource_branch_rotten = "Ramo marcio",
resource_branch_rotten_plural = "Rami marci",
resource_breadDough = "Impasto Di Pane",
resource_breadDough_plural = "Impasto Di Pane",
resource_breadDoughRotten = "Impasto Di Pane Marcio",
resource_breadDoughRotten_plural = "Impasto Di Pane Marcio",
resource_flaxTwine = "Spago di lino",
resource_flaxTwine_plural = "Spago di lino",
resource_mudBrickWet = "Mattone di fango (bagnato)",
resource_mudBrickWet_plural = "Mattoni di fango (bagnati)",
resource_mudBrickDry = "Mattone di fango (a secco)",
resource_mudBrickDry_plural = "Mattoni di fango (a secco)",
resource_firedBrick = "Mattone cotto",
resource_firedBrick_plural = "Mattoni cotti",
resource_mudTileWet = "Piastrella cruda (bagnata)",
resource_mudTileWet_plural = "Piastrelle crude (bagnate)",
resource_mudTileDry = "Piastrella cruda",
resource_mudTileDry_plural = "Piastrelle crude",
resource_firedTile = "Piastrella",
resource_firedTile_plural = "Piastrelle",
resource_mammothMeat = "Carne di mammut",
resource_mammothMeat_plural = "Carne di mammut",
resource_mammothMeatCooked = "Carne di mammut cotta",
resource_mammothMeatCooked_plural = "Carne di mammut cotta",
								
--resource group
resource_group_seed = "Seme",
resource_group_seed_plural = "Semi",
resource_group_container = "Contenitore",
resource_group_container_plural = "Contenitori",
resource_group_campfireFuel = "Ramo/Registro/Combustibile",
resource_group_campfireFuel_plural = "Rami/Registri/Carburante",
resource_group_kilnFuel = "Ramo/Registro/Combustibile",
resource_group_kilnFuel_plural = "Rami/Registri/Carburante",
resource_group_torchFuel = "Fieno",
resource_group_torchFuel_plural = "Fieno",
resource_group_brickBinder = "Legante (fieno o sabbia)",
resource_group_brickBinder_plural = "Legante (fieno o sabbia)",
resource_group_urnFlour = "Farina",
resource_group_urnFlour_plural = "Farina",
resource_group_urnHulledWheat = "Grano decorticato",
resource_group_urnHulledWheat_plural = "Grano decorticato",
								
--desire
desire_names_none = "Nessuno",
desire_names_mild = "Blando",
desire_names_moderate = "Moderare",
desire_names_strong = "Forte",
desire_names_severe = "Acuto",
desire_sleepDescriptions_none = "Non stanco",
desire_sleepDescriptions_mild = "Un po' stanco",
desire_sleepDescriptions_moderate = "Moderatamente stanco",
desire_sleepDescriptions_strong = "Molto stanco",
desire_sleepDescriptions_severe = "Completamente esausto",
desire_foodDescriptions_none = "Appena mangiato",
desire_foodDescriptions_mild = "Non molto affamato",
desire_foodDescriptions_moderate = "Moderatamente affamato",
desire_foodDescriptions_strong = "Molto affamato",
desire_foodDescriptions_severe = "Estremamente affamato",
desire_restDescriptions_none = "Molto ben riposato",
desire_restDescriptions_mild = "Abbastanza ben riposato",
desire_restDescriptions_moderate = "Vuole riposare",
desire_restDescriptions_strong = "Sovraccaricato di lavoro",
desire_restDescriptions_severe = "Grave affaticamento",
								
-- mood
mood_happySad_name = "Felicità",
mood_happySad_severeNegative = "Estremamente infelice",
mood_happySad_moderateNegative = "Triste",
mood_happySad_mildNegative = "Un po' giù",
mood_happySad_mildPositive = "Positivo",
mood_happySad_moderatePositive = "Felice",
mood_happySad_severePositive = "Molto felice",
mood_confidentScared_name = "Fiducia",
mood_confidentScared_severeNegative = "Terrorizzato",
mood_confidentScared_moderateNegative = "Abbastanza spaventato",
mood_confidentScared_mildNegative = "Un po' preoccupato",
mood_confidentScared_mildPositive = "Cautamente fiducioso",
mood_confidentScared_moderatePositive = "Fiducioso",
mood_confidentScared_severePositive = "Molto fiducioso",
mood_loyalty_name = "Lealtà alla tribù",
mood_loyalty_severeNegative = "Partenza imminente",
mood_loyalty_moderateNegative = "Abbastanza infastidito",
mood_loyalty_mildNegative = "Un po' seccato",
mood_loyalty_mildPositive = "Un po' leale",
mood_loyalty_moderatePositive = "Leale",
mood_loyalty_severePositive = "Molto leale",
								
-- statusEffects
statusEffect_justAte_name = "Ho appena mangiato",
statusEffect_justAte_description = "Ho mangiato del cibo di recente",
statusEffect_goodSleep_name = "Buona dormita",
statusEffect_goodSleep_description = "Ho dormito in un letto sotto una coperta.",
statusEffect_learnedSkill_name = "Hai imparato un'abilità",
statusEffect_learnedSkill_description = "Ho imparato una nuova abilità di recente.",
statusEffect_wellRested_name = "Ben riposato",
statusEffect_wellRested_description = "Ho appena avuto una bella pausa dal lavoro.",
statusEffect_hadChild_name = "Ha avuto un figlio",
statusEffect_hadChild_description = "Ha avuto un figlio di recente.",
statusEffect_optimist_name = "Ottimista",
statusEffect_optimist_description = "Effetto permanente causato dal tratto di personalità ottimista.",
statusEffect_minorInjury_name = "Ferita lieve",
statusEffect_minorInjury_description = "Solo qualche taglio e livido. Dovrebbe guarire da solo ma può essere infettato.",
statusEffect_majorInjury_name = "Grave infortunio",
statusEffect_majorInjury_description = "Può muoversi, ma non può più lavorare. Può guarire lentamente o diventare critico.",
statusEffect_criticalInjury_name = "Ferita critica",
statusEffect_criticalInjury_description = "Ferita pericolosa per la vita. Può guarire lentamente o portare alla morte.",
statusEffect_unconscious_name = "Inconscio",
statusEffect_unconscious_description = "Impossibilitato a muoversi.",
statusEffect_wet_name = "Bagnato",
statusEffect_wet_description = "Ai Sapiens non piace essere bagnati e li farà sentire più freddi. Lasciateli asciugare in un luogo caldo.",
statusEffect_wantsMusic_name = "Ha bisogno di musica",
statusEffect_wantsMusic_description = "I sapiens musicali hanno bisogno di suonare o ascoltare musica di tanto in tanto, altrimenti inizieranno a sentirsi tristi.",
statusEffect_enjoyedMusic_name = "Musica goduta",
statusEffect_enjoyedMusic_description = "Musica riprodotta o ascoltata di recente.",
statusEffect_inDarkness_name = "Scuro",
statusEffect_inDarkness_description = "Non c'è abbastanza luce. Ai Sapiens piace essere in grado di vedere cosa stanno facendo.",
								
--negative
statusEffect_hungry_name = "Affamato",
statusEffect_hungry_description = "Ha bisogno di cibo presto, o comincerà a morire di fame.",
statusEffect_starving_name = "Affamato",
statusEffect_starving_description = "Ha un disperato bisogno di cibo.",
statusEffect_sleptOnGround_name = "Dormito per terra",
statusEffect_sleptOnGround_description = "Non c'erano letti disponibili.",
statusEffect_sleptOutside_name = "Ho dormito fuori",
statusEffect_sleptOutside_description = "Ai Sapiens piace dormire al riparo.",
statusEffect_tired_name = "Stanco",
statusEffect_tired_description = "Ha bisogno di riposo.",
statusEffect_overworked_name = "Sovraccaricato di lavoro",
statusEffect_overworked_description = "Tutti hanno bisogno di una pausa di tanto in tanto.",
statusEffect_exhausted_name = "Affaticato",
statusEffect_exhausted_description = "Ha un disperato bisogno di riposo.",
statusEffect_exhaustedSleep_name = "Esausto",
statusEffect_exhaustedSleep_description = "Ha un disperato bisogno di dormire.",
statusEffect_acquaintanceDied_name = "L'amico è morto",
statusEffect_acquaintanceDied_description = "Conoscevo qualcuno che è morto di recente.",
statusEffect_acquaintanceLeft_name = "Amico a sinistra",
statusEffect_acquaintanceLeft_description = "Conoscevo qualcuno che ha lasciato la tribù di recente.",
statusEffect_familyDied_name = "Il membro della famiglia è morto",
statusEffect_familyDied_description = "Un parente stretto o un amico è morto.",
statusEffect_pessimist_name = "Pessimista",
statusEffect_pessimist_description = "Effetto permanente causato dal tratto di personalità pessimista.",
statusEffect_cold_name = "Freddo",
statusEffect_cold_description = "Ha bisogno di trovare calore.",
statusEffect_veryCold_name = "Molto freddo",
statusEffect_veryCold_description = "Alto rischio di sviluppare ipotermia.",
statusEffect_hot_name = "Piccante",
statusEffect_hot_description = "Ha bisogno di raffreddare.",
statusEffect_veryHot_name = "Molto caldo",
statusEffect_veryHot_description = "Alto rischio di surriscaldamento.",
								
--fuel
fuelGroup_campfire = "Carburante da falò",
fuelGroup_kiln = "Combustibile del forno",
fuelGroup_torch = "Carburante per torcia",
fuelGroup_litObject = "Carburante",
								
--stats
stats_birth = "Nascite",
stats_birth_description = "Numero di nascite nel giorno precedente",
stats_recruit = "Assunzioni",
stats_recruit_description = "Numero di sapiens reclutati il ​​giorno precedente",
stats_death = "Deceduti",
stats_death_description = "Numero di sapiens morti il ​​giorno precedente",
stats_leave = "Abbandoni",
stats_leave_description = "Numero di sapiens che hanno lasciato la tribù il giorno precedente",
stats_population = "Popolazione",
stats_population_description = "Numero totale di sapiens nella tribù",
stats_populationChild = "Popolazione infantile",
stats_populationChild_description = "Numero di bambini nella tribù",
stats_populationAdult = "Popolazione adulta",
stats_populationAdult_description = "Numero di adulti nella tribù",
stats_populationElder = "Popolazione anziana",
stats_populationElder_description = "Numero di anziani nella tribù",
stats_populationPregnant = "Popolazione incinta",
stats_populationPregnant_description = "Numero di donne incinte nella tribù",
stats_populationBaby = "Popolazione neonatale",
stats_populationBaby_description = "Numero di bambini nella tribù",
stats_averageHappiness = "% di felicità media",
stats_averageHappiness_description = "Percentuale media di felicità tra tutti i sapiens della tribù",
stats_averageLoyalty = "% fedeltà media",
stats_averageLoyalty_description = "Percentuale media di fedeltà tra tutti i sapiens della tribù",
stats_averageSkill = "Conteggio abilità medio",
stats_averageSkill_description = "Numero medio di abilità che ogni sapien possiede",
stats_bedCount = "Conteggio letti",
stats_bedCount_description = "Numero di posti letto attualmente disponibili per l'uso da parte del tuo sapiens",
stats_foodCount = "Conteggio cibo",
stats_foodCount_description = "Numero di prodotti alimentari conservati nelle aree di stoccaggio",
stats_resource_description = function(values)
return  string.format("Numero di %s attualmente archiviati nelle tue aree di archiviazione", values.resourcePlural)				
end,
stats_currentValue = function(values)
return  string.format("Attuale: %s", values.currentValue)				
end,
								
-- nomadTribeBehavior
nomadTribeBehavior_foodRaid_name = "Incursione alimentare",
nomadTribeBehavior_friendlyVisit_name = "In visita (amichevole)",
nomadTribeBehavior_cautiousVisit_name = "Visitare (prudente)",
nomadTribeBehavior_join_name = "Vuole unirsi alla tribù",
nomadTribeBehavior_passThrough_name = "Passare attraverso",
nomadTribeBehavior_leave_name = "Partenza",
								
-- manageUI
manage_build = "Costruire",
manage_tribe = "Tribù",
manage_storageLogistics = "Itinerari",
								
-- build ui
build_ui_build = "Costruire",
build_ui_place = "Decorare",
build_ui_plant = "Pianta",
build_ui_path = "Percorsi",
								
--construct ui
construct_ui_needsDiscovery = "Indagare gli oggetti per fare una svolta necessaria",
construct_ui_unseenResources = "Trova o crea un oggetto richiesto",
construct_ui_unseenTools = "Trova o crea uno strumento richiesto",
construct_ui_acceptOnly = "Accetta solo",
construct_ui_requires = "Richiede",
construct_ui_rdisabledInResourcesPanel = "L'uso di questa risorsa è stato disabilitato nel pannello delle risorse della tribù",
construct_ui_discoveryRequired = "Scoperta richiesta",
construct_ui_discoveryRequired_plantsInfo = "Per coltivare piante e alberi, la tua tribù deve prima scoprire scavare, scavare e piantare rocce.",
construct_ui_discoveryRequired_pathsInfo = "I percorsi consentono ai sapiens di muoversi più velocemente. Per costruire percorsi, la tua tribù deve prima scoprire gli scavi.",
								
--storage ui
storage_ui_acceptOnly = "Accetta solo",
storage_ui_Unlimited = "Illimitato",
storage_ui_RouteDisabled = "Percorso disabilitato",
storage_ui_routeName = function(values)
return  string.format("Percorso %d", values.count)				
end,
storage_ui_returnToFirstStop = "Torna alla prima fermata quando hai finito",
storage_ui_returnToFirstStop_toolTip = "Dopo che un sapien ha lasciato gli oggetti all'ultima fermata, torneranno di nuovo alla prima fermata.",
storage_ui_removeRouteWhenComplete = "Rimuovi il percorso una volta completato",
storage_ui_removeRouteWhenComplete_toolTip = "Elimina questo percorso quando non ci sono più fermate che richiedono il ritiro.",
storage_ui_maxSapiens = "Massimo Sapiens",
storage_ui_clickToAddStops = "Fare clic sulle aree di archiviazione per aggiungere fermate",
storage_ui_hit = "Colpo",
storage_ui_whenDone = "Quando fatto",
storage_ui_NoDestinations = "Nessuna destinazione",
								
--resources ui
resources_ui_allowUse = "Consenti l'uso",
								
-- tribe ui
tribe_ui_tribe = "Sapiens",
tribe_ui_roles = "Ruoli",
tribe_ui_stats = "Statistiche",
tribe_ui_resources = "Risorse",
								
--settings ui
settings_options = "Impostazioni",
settings_exit = "Uscita",
settings_header = "Impostazioni: Generale",
settings_general = "Generale",
settings_graphics = "Grafica",
settings_KeyBindings = "Legami chiave",
settings_Debug = "Debug",
settings_Exit = "Uscita",
settings_language = "Lingua",
settings_language_tip = "Installa più lingue da Steam Workshop tramite il pannello 'Mod' nel menu principale",
settings_Controls = "Controlli",
settings_Controls_mouseSensitivity = "Sensibilità allo sguardo del mouse",
settings_Controls_invertMouseLookY = "Inverti lo sguardo del mouse Y",
settings_Controls_controllerLookSensitivity = "Sensibilità all'aspetto del controller",
settings_Controls_invertControllerLookY = "Inverti controllore Guarda Y",
settings_Controls_enableDoubleTapForFastMovement = "Tocca due volte Movimento veloce",
settings_Audio = "Audio",
settings_Audio_MusicVolume = "Volume della musica",
settings_Audio_SoundVolume = "Volume del suono",
settings_Other = "Altro",
settings_allowLanConnections = "Consenti connessioni LAN multiplayer",
settings_enableTutorialForThisWorld = "Abilita tutorial per questo mondo",
settings_enableTutorialForNewWorlds = "Abilita tutorial per nuovi mondi",
settings_GeneralGraphics = "Grafica generale",
settings_graphics_brightness = "Luminosità",
settings_graphics_desktop = "Desktop",
settings_graphics_Multi = "Multi",
settings_graphics_Resolution = "Risoluzione",
settings_graphics_Display = "Schermo",
settings_graphics_window = "Finestra",
settings_graphics_Borderless = "Senza confini",
settings_graphics_FullScreen = "A schermo intero",
settings_graphics_Relaunch = "Rilancio",
settings_graphics_VSync = "VSync",
settings_graphics_FOV = "FOV",
settings_Performance = "Prestazione",
settings_Performance_RenderDistance = "Rendering distanza",
settings_Performance_GrassDistance = "Distanza dall'erba",
settings_Performance_grassDensity = "Densità dell'erba",
settings_Performance_animatedObjectsCount = "Numero massimo di oggetti animati",
settings_Performance_ssao = "Occlusione ambientale",
settings_Debug_display = "Visualizzazione di debug",
settings_Debug_Cloud = "Nube",
settings_Debug_setSunrise = "Impostare l'alba",
settings_Debug_setMidday = "Impostare mezzogiorno",
settings_Debug_setSunset = "Impostare il tramonto",
settings_Debug_startLockCamera = "Blocca fotocamera",
settings_Debug_startServerProfile = "Server di profilo",
settings_Debug_startLogicProfile = "Thread logico del profilo",
settings_Debug_startMainThreadProfile = "Discussione principale del profilo",
settings_exitAreYouSure = "Sei sicuro di voler uscire da Sapiens?",
settings_exitAreYouSure_info = "Il gioco viene salvato costantemente mentre giochi.",
settings_exitMainMenu = "Esci al menu principale",
settings_exitDesktop = "Esci su desktop",
--stats ui
ui_stats_days_ago = function(values)
return  string.format("%d Giorni fa", values.dayCount)				
end,
ui_stats_now = "Adesso",
								
--roles ui
ui_roles_allowed = "Assegnato",
ui_roles_disallowed = "Non assegnato",
								
-- resources ui
ui_resources_allResourceType = function(values)
return  string.format("Tutti %s", values.resourceName)				
end,
ui_resources_storedCount = function(values)
return  string.format("%s memorizzato", values.storedCount)				
end,
ui_resources_decorations = "Luogo decorazione",
ui_resources_eating = "Mangiare",				
								
-- look at ui
lookatUI_needs = "Necessità",
lookatUI_missingStorage = "Nessuna area di stoccaggio corrispondente o vuota nelle vicinanze",
lookatUI_missingCraftArea = "Nessuna zona artigianale nelle vicinanze",
lookatUI_missingCampfire = "Nessun falò acceso nelle vicinanze",
lookatUI_missingKiln = "Nessun forno acceso nelle vicinanze",
lookatUI_missingStorageAreaContainedObjects = "Nessun articolo adatto memorizzato qui",
lookatUI_missingTaskAssignment = function(values)
	return "No capable sapiens near by with the \"" .. values.taskName .. "\" role"
end,
lookatUI_needsTools = function(values)-- b16
local planInfoString = "Necessità"			
for i,missingToolInfo in ipairs(values.missingToolInfos) do
planInfoString = planInfoString .. missingToolInfo.toolName .. " (es. " .. missingToolInfo.exampleObjectName ..	")"		
if i ~= #values.missingToolInfos then
planInfoString = planInfoString ..", "			
end
end
return  planInfoString
end,
lookatUI_needsResources = function(values)-- b16
local planInfoString = "Necessità "			
for i,missingResourceString in ipairs(values.missingResources) do
planInfoString = planInfoString .. missingResourceString
if i ~= #values.missingResources then
planInfoString = planInfoString ..", "			
end
end
return  planInfoString
end,
lookatUI_inaccessible = "Troppo difficile da raggiungere",
lookatUI_terrainTooSteepFill = "Riempirlo creerebbe una pendenza troppo ripida",
lookatUI_invalidUnderWater = "Necessita di accesso da terraferma",
lookatUI_terrainTooSteepDig = "Scavare questo creerebbe un pendio troppo ripido",
lookatUI_needsLit = "Deve essere acceso prima",
lookatUI_disabledDueToOrderLimit = "Numero massimo di ordini raggiunto",
lookatUI_tooDark = "Non abbastanza luce. Aggiungi torce o attendi fino al giorno",
lookatUI_tooDistant = "Nessun sapiens capace nelle vicinanze con il ruolo richiesto assegnato",
lookatUI_tooDistantWithRoleName = function(values)
	return "No capable sapiens near by with the \"" .. values.taskName .. "\" role"	
end,
lookatUI_tooDistantRequiresCapable = function(values)
        return "No capable sapiens near by with the \"" .. values.taskName .. "\" role (Requires heavy lifting)"
end,
								
sapien_ui_roles = "Ruoli",
sapien_ui_inventory = "Inventario",
sapien_ui_relationships = "Famiglia",
								
-- ui actions
ui_action_chooseTribe = "Guida questa tribù",
ui_action_place = "Posto",
ui_action_plant = "Pianta",
ui_action_build = "Costruire",
ui_action_craft = "Mestiere",
ui_action_continue = "Continua",
ui_action_craft_continuous = "Crea continuamente",
ui_action_assign = "Assegnare",
ui_action_cancel = "Annulla",
ui_action_cancelling = "Cancellazione",
ui_action_stop = "Fermare",
ui_action_next = "Prossimo",
ui_action_choose = "Scegliere",
ui_action_set = "Impostare",
ui_action_zoom = "Ingrandisci",
ui_action_remove = "Rimuovere",
ui_action_manageRoles = "Gestisci ruoli",
ui_action_disallowAll = "Annulla assegnazione tutto",
ui_action_allowAll = "Assegna tutto",
ui_action_allow = "Assegnare",
ui_action_disallow = "Annulla assegnazione",
ui_action_selectMore = "Seleziona Altro",
ui_action_select = "Selezionare",
ui_action_boxSelect = "Seleziona casella",
ui_action_radiusSelect = "Seleziona raggio",
ui_action_editName = "Rinominare",
ui_action_inspectRoute = "Ispeziona il percorso",
ui_action_assignDifferentSapien = "Assegna Sapien diverso",
ui_action_assignSapien = "Assegna Sapien",
ui_action_prioritize = "Dare priorità",
ui_action_manageSapien = function(values)
return "Gestire " .. values.name				
end,
ui_action_join = "Giuntura",
ui_action_createWorld = "Crea mondo",
ui_action_credits = "Crediti",
ui_action_exit = "Uscita",
ui_action_reportBug = "Segnala un errore",
ui_action_importReports = "Importa rapporti",
ui_action_wishlist = "Aggiungi alla tua lista dei desideri",
ui_action_wishlistNow = "Lista dei desideri ora!",
ui_action_sendFeedback = "Invia feedback",
ui_action_apply = "Applicare",
ui_action_dontShowAgain = "Non mostrarlo di nuovo",
ui_action_attemptToPlayAnyway = "Prova comunque a giocare",
ui_action_setFillType = "Imposta il tipo di riempimento",							
								
--ui plans
ui_plan_unavailable_stopOrders = "Annulla prima altri ordini",
ui_plan_unavailable_multiSelect = "Troppi selezionati",
ui_plan_unavailable_missingKnowledge = "Conoscenza mancante",
ui_plan_unavailable_investigatedElsewhere = "Indagato altrove",
ui_plan_unavailable_extinguishFirst = "Spegni prima",
								
								
-- ui buildMode
ui_buildMode_fail_needsAttachment = "Ha bisogno di attaccarsi a qualcosa",
ui_buildMode_fail_collidesWithObjects = "Si scontra con qualcosa",
ui_buildMode_fail_tooSteep = "La pendenza è troppo ripida",
ui_buildMode_fail_underwater = "Non posso costruire sott'acqua",
ui_buildMode_plantFail_tooDistant = "Troppo lontana",
ui_buildMode_plantFail_notTerrain = "Ha bisogno di essere piantato nel terreno",
ui_buildMode_plantFail_badMedium = function(values)
return "Non può essere piantato" .. values.terrainName				
end,
ui_buildMode_fail_belowTerrain = "Non è possibile costruire sotto il terreno",
fill_summary = function(values)
if values.requiredResourceCount > 1 then
return  string.format("Riempi il terreno con %d %s", values.requiredResourceCount, values.resourceTypeNamePlural)				
else
return "Riempi il terreno con" .. values.resourceTypeNamePlural				
end
end,
ui_cantDoTasks = function(values)
if values.pregnant then
return "Non è possibile svolgere questi compiti a causa della gravidanza."			
elseif values.hasBaby then
return "Non è possibile svolgere questi compiti mentre si trasporta un bambino."			
elseif values.child then
return "I bambini non possono svolgere questi compiti."			
elseif values.elder then
return "Gli anziani non possono svolgere questi compiti."			
elseif values.maxAssigned then
return "Numero massimo di ruoli assegnati"			
end
return "Impossibile eseguire compiti a causa di capacità limitate."			
end,
ui_partiallyCantDoTasks = function(values)
if values.pregnant then
return "Alcuni di questi compiti non possono essere eseguiti a causa della gravidanza."			
elseif values.hasBaby then
return "Alcuni di questi compiti non possono essere eseguiti durante il trasporto di un bambino."			
elseif values.child then
return "I bambini non possono svolgere alcuni di questi compiti."			
elseif values.elder then
return "Gli anziani non possono svolgere alcuni di questi compiti."			
end
return "Alcune di queste attività non possono essere eseguite a causa delle capacità limitate."			
end,
ui_cantDoTasksShort = function(values)
if values.pregnant then
return "Incinta"			
elseif values.hasBaby then
return "Portare bambino"			
elseif values.child then
return "Bambino"			
elseif values.elder then
return "Sambuco"			
elseif values.maxAssigned then
return "Massimo assegnato"			
end
return "Abilità limitata"			
end,
ui_missingTaskAssignment = function(values)
	return "No capable sapiens near by with the \"" .. values.taskName .. "\" role"
end,
ui_portionCount = function(values)
if values.portionCount == 1 then
return  string.format("1 porzione")				
else
return  string.format("%d porzioni", values.portionCount)				
	end
end,
								
								
-- ui names
ui_name_traits = "Tratti",
ui_name_skillFocus = "Focus sulle abilità",
ui_name_relationships = "Famiglia",
ui_name_tasks = "Ruoli",
ui_name_move = "Spostare",
ui_name_moveAndWait = "Muoviti e aspetta",
ui_name_assignBed = "Assegna letto", --b20				
ui_name_mapMode = "Mappa del mondo",
ui_name_changeAssignedSapien = "Seleziona un Sapien da assegnare",
ui_name_tutorial = "Esercitazione",
ui_name_terrain = "Terreno",
ui_name_craftCount = "Conte artigianale",
ui_name_ipAddress = "Indirizzo IP/Host",
ui_name_port = "Porta (predefinito 16161)",
ui_name_notApplicable = "N/A",
ui_name_today = "In data odierna",
ui_name_yesterday = "Ieri",
ui_daysAgo = function(values)
return  string.format("%d giorni fa", values.count)				
end,
    ui_name_lastPlayed = "Ultimo avvio",
    ui_name_created = "Creato",
    ui_name_lastPlayedVersion = "Ultima versione giocata",
    ui_name_worldAge = "Età del Mondo (giorni di gioco)", --b20
    ui_name_seed = "Seme",
    ui_name_manage = "Gestisci", --b20
    ui_name_saves = "Salvataggi",
    ui_name_load = "Carica",
    ui_name_deleteWorld = "Elimina Mondo",
    ui_name_changeMods = "Cambia Mods", --b20
    ui_name_updateMod = "Aggiorna Mod", --b20
    ui_name_steamOverlayDisabled = "Richiede l'Overlay di Steam", --b20																  
								
								
-- ui infos
ui_info_deleteWorldAreYouSure = function(values)
return  string.format("Sei sicuro di voler eliminare il mondo %s? Questo non può essere annullato, il salvataggio del gioco sarà perso per sempre.", values.worldName)				
end,
ui_info_bindingPopUpViewInstructions = "Premere e rilasciare i tasti da assegnare a questa associazione.",
ui_info_bindingTimeRemaining = function(values)
return  string.format("Ripristina tra %d secondi...", values.seconds)				
end,
    ui_info_changeModAreYouSure = "Are you sure you want to change the mods for this world?\n\nThis can cause the world to fail to load, so you should backup a copy of the world's directory first.", --b20
    ui_info_updateModAreYouSure = function(values) --b20
        return string.format("Are you sure you want to update the mod %s?\n\nThis cannot be undone and can cause the world to fail to load.\n\nIt will copy the latest version (%s) of the mod into this world's directory, overwriting the old version (%s).\n\nYou should backup a copy of the world's directory first.", values.modName, values.newVersion, values.oldVersion)
    end, 
    ui_info_steamOverlayDisabled = "This feature requires the Steam Overlay.\n\nYou can enable the Steam Overlay from within the Steam app, either for all games, or just for Sapiens.", --b20
								
								
ui_pause = "Pausa",
ui_play = "Riprendi",
ui_fastForward = "Avanti veloce",
								
    ui_objectBelongingToSapien = function(values) --b20													   
        return string.format("%s's %s", values.sapienName, values.objectName)
    end, 
								
tribeUI_sapien = "Sapien",
tribeUI_distance = "Dist.",
tribeUI_age = "Età",
tribeUI_happiness = "Felice",
tribeUI_loyalty = "Lealtà",
tribeUI_effects = "Effetti",
tribeUI_roles = "Ruoli",
tribeUI_skills = "Abilità",
tribeUI_population = "Popolazione",
								
--misc
misc_no_summary_available = "Nessun riepilogo disponibile",
misc_missing_name = "Senza nome",
misc_none_assigned = "Nessuno assegnato",
misc_place_object_summary = "Posiziona in qualsiasi parte del mondo a scopo decorativo.",
misc_undiscovered = "da scoprire",
misc_dry = "Asciutto",
misc_newBreakthrough = "Nuova svolta!",
misc_unlocks = "Sblocca",
misc_pregnant = "Incinta",
misc_carryingBaby = "Portare bambino",
misc_unnamed = "Senza nome",
misc_inside = "dentro",
misc_outside = "fuori",
misc_acceptAll = "Accettare tutti",
misc_uncheckDestroyFirst = "Non posso accettare tutto con Destroy All Items",
misc_acceptNone = "Accetta Nessuno",
misc_route = "Percorso",
misc_items = "Elementi",
misc_specialOrders = "Ordini speciali",
misc_allowItemUse = "Consenti l'uso dell'oggetto",
misc_itemUseNotAllowed = "Uso dell'oggetto non consentito",
misc_removeAllItems = "Rimuovi tutti gli elementi",
misc_destroyAllItems = "Distruggi tutti gli oggetti",
misc_routes = "Itinerari",
misc_addStops = "Aggiungi fermate",
misc_addNewRoute = "Aggiungi nuovo percorso",
misc_addNewRouteStartingHere = "Aggiungi un nuovo percorso a partire da qui",
misc_setFillType = "Imposta il tipo di riempimento",
misc_debug = "Debug",
misc_cheat = "Imbroglione",
misc_fmodCredit = "Per l'audio, Sapiens utilizza FMOD Studio di Firelight Technologies Pty Ltd.",
misc_version = "Versione",
misc_demo = "Demo",
misc_forums = "Forum Sapiens",
misc_discord = "Sapiens Discordia",
misc_twitter = "Sapiens su Twitter",
misc_serverNotFound = "Impossibile trovare il server",
misc_serverNotFound_info = "Il server potrebbe essere offline o irraggiungibile",
misc_connectionLost = "Collegamento perso",
misc_connectionLost_info = "La connessione al server è stata interrotta",
misc_random = "A caso",
misc_randomVariation = "Variazione casuale",
misc_variations = "Variazioni",
misc_skilled = "Abile",
misc_noSelection = "Nessuna selezione",
misc_unavailable = "Non disponibile",
misc_elsewhere = "Altrove",
misc_cantDoPlan = function(values)
return  string.format("Impossibile %s", values.planName)				
end,
								
    
    misc_settings = "Impostazioni",
    misc_continuous = "Continuous",
    misc_Empty = "Vuoto",
    misc_Unknown = "Sconosciuto",
    misc_Rebinding = "Rebinding",
    misc_NotLoaded = "Non caricato",
    misc_Toggle = "Toggle",
    misc_Biome = "Bioma",
    misc_BiomeDifficulty = "Location Difficulty", --b20
    misc_BiomeDifficulty_veryEasy = "Very Easy", --b20
    misc_BiomeDifficulty_easy = "Easy", --b20
    misc_BiomeDifficulty_normal = "Normal", --b20
    misc_BiomeDifficulty_hard = "Hard", --b20
    misc_BiomeDifficulty_veryHard = "Very Hard", --b20
    misc_WIP_Panel = "This panel is not ready yet, Coming soon!",
    misc_decorate_with = function(values)--b13
        return string.format("Decorate With %s", values.name)
    end,
                                            
								
--loading
loading_connecting = "Connessione al server",
loading_connected = "Connesso al server",
loading_loadingShaders = "Caricamento degli shader",
loading_waiting = "In attesa del server",
loading_generating = "Generazione del mondo",
loading_world = "Caricamento del mondo",
loading_downloadingData = "Download di dati/mod del mondo",
loading_downloading = "Download",
loading_loading = "Caricamento in corso",
								
-- lifeStages
lifeStages_child = "Bambino",
lifeStages_adult = "Adulto",
lifeStages_elder = "Sambuco",
								
--sapienTrait
sapienTrait_charismatic = "Carismatico",
sapienTrait_loyal = "Leale",
sapienTrait_courageous = "Coraggioso",
sapienTrait_courageous_opposite = "Pauroso",
sapienTrait_strong = "Forte",
sapienTrait_focused = "focalizzata",
sapienTrait_logical = "Logico",
sapienTrait_creative = "Creativo",
sapienTrait_clever = "Studente veloce",
sapienTrait_clever_opposite = "Apprendista lento",
sapienTrait_lazy = "Pigro",
sapienTrait_lazy_opposite = "Energico",
sapienTrait_longSleeper = "Dormiente lungo",
sapienTrait_longSleeper_opposite = "Mattiniero",
sapienTrait_glutton = "Ghiottone",
sapienTrait_glutton_opposite = "Piccolo Mangiatore",
sapienTrait_optimist = "Ottimista",
sapienTrait_optimist_opposite = "Pessimista",
sapienTrait_musical = "Musicale",
sapienTrait_musical_opposite = "Stonata",
								
--skill
skill_gathering = "Lavoro generale",
skill_gathering_description = "Trasportare oggetti, eliminare l'erba e raccogliere risorse da piante e alberi.",
skill_basicBuilding = "Edificio di base",
skill_basicBuilding_description = "Costruisci oggetti di base come letti e aree di artigianato/ripostiglio e posiziona oggetti.",
skill_woodBuilding = "Edificio in legno",
skill_woodBuilding_description = "Costruisci strutture in legno.",
skill_basicResearch = "Indagine",
skill_basicResearch_description = "Indaga sugli oggetti per fare scoperte e far avanzare le conoscenze della tribù.",
skill_diplomacy = "Diplomazia",
skill_diplomacy_description = "Ispira altri sapiens a unirsi e rimanere nella tua tribù, o convincili ad andarsene.",
skill_fireLighting = "Illuminazione del fuoco",
skill_fireLighting_description = "Il fuoco fornisce calore e luce e consente di cuocere gli alimenti per aumentarne il valore nutritivo.",
skill_knapping = "Rock Knapping",
skill_knapping_description = "Crea strumenti rocciosi primitivi e dividi rocce grandi in rocce più piccole.",
skill_flintKnapping = "Selce Knapping",
skill_flintKnapping_description = "Crea strumenti di selce, che durano più a lungo e sono più affilati.",
skill_boneCarving = "Intaglio delle ossa",
skill_boneCarving_description = "Crea lame affilate e strumenti musicali dall'osso.",
skill_flutePlaying = "Musica",--the key is flutePlaying, but the translation should be for playing all instruments eg	Music			
skill_flutePlaying_description = "La musica aiuta a unire la tua tribù, aumentando la lealtà e la felicità delle persone vicine.",
skill_pottery = "Ceramica",
skill_pottery_description = "Creare urne cinerarie e mattoni di fango.",
skill_potteryFiring = "Ceramica",
skill_potteryFiring_description = "Urne e mattoni.",
skill_spinning = "Filatura del lino",
skill_spinning_description = "Crea spaghi e corde dalle fibre vegetali.",
skill_thatchBuilding = "Edificio di paglia",
skill_thatchBuilding_description = "Costruisci semplici ripari con fieno o canne e rami.",
skill_mudBrickBuilding = "Edificio in mattoni di fango",
skill_mudBrickBuilding_description = "Costruisci strutture con mattoni di fango.",
skill_brickBuilding = "Edificio in mattoni",
skill_brickBuilding_description = "Costruisci strutture con mattoni cotti.",
skill_tiling = "Piastrellatura",
skill_tiling_description = "Costruisci tetti, pavimenti e percorsi con piastrelle di ceramica.",
skill_basicHunting = "Caccia di base",
skill_basicHunting_description = "Caccia piccole prede lanciando semplici proiettili.",
skill_spearHunting = "Caccia alla lancia",
skill_spearHunting_description = "Caccia prede più grandi e veloci lanciando lance.",
skill_butchery = "La macelleria",
skill_butchery_description = "Carcasse del macellaio per fornire carne.",
skill_campfireCooking = "Cucina di base",
skill_campfireCooking_description = "Cuocere la carne per fornire più valore nutritivo.",
skill_baking = "Cottura al forno",
skill_baking_description = "Incorporare la farina nell'impasto del pane e cuocerla per creare un pasto nutriente.",
skill_treeFelling = "Abbattimento di alberi",
skill_treeFelling_description = "Taglia gli alberi usando strumenti manuali.",
skill_woodWorking = "Lavorazione del legno",
skill_woodWorking_description = "Crea oggetti con rami e tronchi.",
skill_toolAssembly = "Assemblaggio degli strumenti",
skill_toolAssembly_description = "Crea strumenti più complessi combinando più componenti.",
skill_digging = "Scavando",
skill_digging_description = "Scava e riempi terreno, sabbie e argille.",
skill_mining = "Estrazione",
skill_mining_description = "Estrai materiali duri, come il rock.",
skill_planting = "Piantare",
skill_planting_description = "Pianta i semi per coltivare alberi e colture.",
skill_threshing = "Trebbiatura",
skill_threshing_description = "Trebbiare i grani per renderli pronti per la macinazione o la cottura.",
skill_grinding = "Rettifica",
skill_grinding_description = "Polverizza i cereali per sbloccare la nutrizione all'interno.",
								
--storage
storage_rockSmall = "Piccole rocce",
storage_seed = "Semi",
storage_rock = "Grandi rocce",
storage_log = "Registri",
storage_woodenPole = "Pali di legno",
storage_woolskin = "Pelli di lana",
storage_bone = "Ossa",
storage_pineCone = "Pigne",
storage_pineConeBig = "Grandi pigne",
storage_deadChicken = "Carcasse di pollo",
storage_beetroot = "Barbabietole",
storage_wheat = "Grano",
storage_flax = "Lino",
storage_knife = "Coltelli",
storage_axeHead = "Teste d'ascia",
storage_pickaxeHead = "Teste di piccone",
storage_pickaxe = "Picconi",
storage_hatchet = "accette",
storage_branch = "Rami",
storage_spearHead = "Punte di lancia",
storage_raspberry = "Lamponi",
storage_peach = "Pesche",
storage_flatbread = "Focacce",
storage_spear = "lance",
storage_dirt = "Suolo",
storage_flint = "pietra focaia",
storage_clay = "Argilla",
storage_sand = "Sabbia",
storage_orange = "Arance",
storage_splitLog = "Registri divisi",
storage_chickenMeat = "Carne di gallina",
storage_hayGrass = "Fieno",
storage_deadAlpaca = "Carcasse di alpaca",
storage_apple = "Mele",
storage_banana = "Banane",
storage_coconut = "Noci di cocco",
storage_alpacaMeat = "Carne di alpaca",
storage_gooseberry = "Uva spina",
storage_pumpkin = "Zucche",
storage_urn = "Urne",
storage_quernstone = "Quern-pietre",
storage_breadDough = "Impasto Di Pane",
storage_brick = "Mattoni",
storage_mammothMeat = "Carne di mammut",
storage_flaxTwine = "Spago di lino",
storage_boneFlute = "Flauti d'osso",
storage_logDrum = "Log tamburi",
storage_balafon = "Balafons",
storage_tile = "Piastrelle",
								
-- constructable_classification
constructable_classification_build = "Edifici",
constructable_classification_build_action = "Costruire",
constructable_classification_plant = "Piante/Alberi",
constructable_classification_plant_action = "Pianta",
constructable_classification_craft = "Oggetti artigianali",
constructable_classification_craft_action = "Mestiere",
constructable_classification_path = "Percorsi",
constructable_classification_path_action = "Costruire",
constructable_classification_place = "Posiziona oggetto",
constructable_classification_place_action = "Posto",
constructable_classification_fill = "Riempi il terreno",
constructable_classification_fill_action = "Riempire",
constructable_classification_research = "Scoperte",
constructable_classification_research_action = researchName,
								
--evolution
evolution_dryAction = "Si asciuga",
evolution_rotAction = "marcisce",
evolution_despawnAction = "Andato",
evolution_time_verySoon = "molto presto",
evolution_time_fewHours = "in poche ore",
evolution_time_fewDays = "in pochi giorni",
evolution_time_nextYear = "l'anno prossimo",
evolution_time_fewYears = "in pochi anni",
evolution_timeFunc = function(values)
return  values.actionName .. " " .. values.time				
end,
								
-- time
time_year = "Anno",
time_year_plural = "Anni",
time_day = "Giorno",
time_day_plural = "Giorni",
time_second = "Secondo",
time_second_plural = "Secondi",
								
--weather
weather_temperatureZone_veryCold = "Molto freddo",
weather_temperatureZone_cold = "Freddo",
weather_temperatureZone_moderate = "Caldo",
weather_temperatureZone_hot = "Piccante",
weather_temperatureZone_veryHot = "Molto caldo",
								
-- keyMaps
keygroup_game = "Gioco",
keygroup_menu = "Menù",
keygroup_movement = "Movimento",
keygroup_building = "Costruzione",
keygroup_textEntry = "Inserimento di testo",
keygroup_debug = "Debug",
keygroup_multiSelect = "Selezione multipla",
keygroup_cinematicCamera = "Camera cinematografica",
								
-- key_game
key_game_escape = "Chiudi/Nascondi",
key_game_chat = "Chiacchierata",
key_game_toggleMap = "Carta geografica",
key_game_confirm = "Conferma/Inserisci",
key_game_confirmSpecial = "Conferma secondaria",
key_game_menu = "Apri menu",
key_game_buildMenu = "Apri il menu Crea",
key_game_buildMenu2 = "Apri menu build (alternativa)",
key_game_tribeMenu = "Apri il menu della tribù",
key_game_routesMenu = "Apri il menu Percorsi",
key_game_settingsMenu = "Apri il menu delle impostazioni",
key_game_zoomToNotification = "Zoom su notifica",
key_game_pause = "Pausa/Riattiva",
key_game_speedFast = "Attiva o disattiva l'accelerazione del tempo",
key_game_speedSlowMotion = "Velocità di gioco al rallentatore",
key_game_radialMenuShortcut1 = "Menu di scelta rapida radiale 1",
key_game_radialMenuShortcut2 = "Scorciatoia del menu radiale 2",
key_game_radialMenuShortcut3 = "Scorciatoia del menu radiale 3",
key_game_radialMenuShortcut4 = "Scelta rapida del menu radiale 4",
key_game_radialMenuShortcut5 = "Scelta rapida del menu radiale 5",
key_game_radialMenuAutomateModifier = "Modificatore di automazione del menu radiale",
key_game_radialMenuDeconstruct = "Menu radiale Rimuovi/distruggi",
key_game_zoomModifier = "Modificatore di clic dello zoom",
key_game_multiselectModifier = "Modificatore di clic a selezione multipla",
key_game_radialMenuClone = "Menu radiale Costruisci di più",--b13				
								
-- key_menu
key_menu_up = "Su",
key_menu_down = "Fuori uso",
key_menu_left = "Sono partiti",
key_menu_right = "Destra",
key_menu_select = "Selezionare",
key_menu_back = "Di ritorno",
								
-- key_movement
key_movement_forward = "Inoltrare",
key_movement_back = "Di ritorno",
key_movement_left = "Sono partiti",
key_movement_right = "Destra",
key_movement_slow = "Lento",
key_movement_fast = "Veloce",
key_movement_forwardAlt = "Attaccante (alternativa)",
key_movement_backAlt = "Indietro (alternativa)",
key_movement_leftAlt = "Sinistra (alternativa)",
key_movement_rightAlt = "Destra (alternativa)",
key_building_cancel = "Annulla",
key_building_confirm = "Confermare",
key_building_zAxisModifier = "Cambio asse / Disattiva snap",
key_building_adjustmentModifier = "Posizionamento Fine Tune Modifier",
key_building_noBuildOrderModifier = "Posizionamento Nessun modificatore dell'ordine di costruzione",
key_building_rotateX = "Ruota di 90 sull'asse X",
key_building_rotateY = "Ruota di 90 sull'asse Y",
key_building_rotateZ = "Ruota di 90 sull'asse Z",
key_textEntry_backspace = "Backspace",
key_textEntry_send = "Invia/Invio",
key_textEntry_newline = "Nuova linea",
key_textEntry_prevCommand = "Precedente",
key_textEntry_nextCommand = "Prossimo",
								
-- key_multiSelect
key_multiSelect_subtractModifier = "Modificatore di sottrazione",
								
-- key_debug
key_debug_reload = "Ricaricare",
key_debug_lockCamera = "Blocca fotocamera",
key_debug_setDebugObject = "Imposta oggetto di debug",
								
-- key_cinematicCamera
key_cinematicCamera_startRecord1 = "Inizia la registrazione 1",
key_cinematicCamera_startRecord2 = "Inizia la registrazione 2",
key_cinematicCamera_startRecord3 = "Inizia la registrazione 3",
key_cinematicCamera_startRecord4 = "Inizia la registrazione 4",
key_cinematicCamera_startRecord5 = "Inizia la registrazione 5",
key_cinematicCamera_play1 = "Gioca 1",
key_cinematicCamera_play2 = "Gioca 2",
key_cinematicCamera_play3 = "Gioca 3",
key_cinematicCamera_play4 = "Gioca 4",
key_cinematicCamera_play5 = "Gioca 5",
key_cinematicCamera_stop = "Interrompi la riproduzione",
key_cinematicCamera_insertKeyframe = "Inserisci fotogramma chiave",
key_cinematicCamera_saveKeyframe = "Salva fotogramma chiave",
key_cinematicCamera_removeKeyframe = "Rimuovi fotogramma chiave",
key_cinematicCamera_nextKeyframe = "Fotogramma chiave successivo",
key_cinematicCamera_prevKeyframe = "Fotogramma chiave precedente",
key_cinematicCamera_increaseKeyframeDuration = "#ERROR!",
key_cinematicCamera_decreaseKeyframeDuration = "- Durata fotogramma chiave",
								
-- selection groups
selectionGroup_branch_objectName = "Ramo",
selectionGroup_branch_plural = "Rami",
selectionGroup_branch_descriptive = "Qualsiasi filiale",
selectionGroup_log_objectName = "Tronco d'albero",
selectionGroup_log_plural = "Registri",
selectionGroup_log_descriptive = "Qualsiasi registro",
selectionGroup_rock_objectName = "Roccia",
selectionGroup_rock_plural = "Rocce",
selectionGroup_rock_descriptive = "Qualsiasi roccia",
selectionGroup_smallRock_objectName = "Piccola Roccia",
selectionGroup_smallRock_plural = "Piccole rocce",
selectionGroup_smallRock_descriptive = "Qualsiasi piccola roccia",
								
-- notifications
notification_becamePregnant = function(values)
return  values.name .. " è incinta"			
end,
notification_babyBorn = function(values)
local gender = "Ragazza"			
if not values.babyIsFemale then
gender = "Ragazzo"			
end
return  values.parentName .. "ha avuto un bambino" .. gender				
end,
notification_babyGrew = function(values)
return  values.parentName .. "Il bambino è cresciuto in un bambino ed è stato nominato" .. values.childName				
end,
notification_agedUp = function(values)
if values.lifeStageName then
return  values.name .. "ora è un " .. string.lower(values.lifeStageName)				
end
return  values .. "invecchiato"			
end,
notification_died = function(values)
return  values.name .. "è morto. Motivo: ".. values.deathReason				
end,
notification_left = function(values)
return  values.name .. "ha lasciato la tribù."			
end,
notification_lowLoyalty = function(values)
return  values.name .. "potrebbe lasciare la tribù presto."			
end,
notification_recruited = function(values)
return  values.name .. "si è unito alla tua tribù"			
end,
notification_skillLearned = function(values)
return  values.name .. "ha imparato il" .. values.skillName ..	skill			
end,
notification_newTribeSeen = function(values)
return "Un'altra tribù è stata avvistata"			
end,
notification_discovery = function(values)
        return "La tua tribù ha scoperto " .. values.skillName .. "!"	
end,
notification_researchNearlyDone = function(values)
return "La svolta è quasi completa!"			
end,
notification_mammothKill = function(values)
return  values.name .. "ha ucciso un mammut"			
end,
notification_minorInjuryByMob = function(values)
return  values.name .. "è stato ferito da a" .. values.mobTypeName				
    end,
    --b13
    notification_majorInjuryByMob = function(values)
        return values.name .. " has been majorly injured by a " .. values.mobTypeName
    end,
    notification_criticalInjuryByMob = function(values)
        return values.name .. " has been critically injured by a " .. values.mobTypeName
    end,
    notification_majorInjuryDeveloped = function(values)
        return values.name .. "'s injury has become major"
    end,
    notification_criticalInjuryDeveloped = function(values)
        return values.name .. "'s injury has become critical"
    end,
    --/b13
-- menues
menu_createWorld = "Crea mondo",
menu_worldName = "Nome Mondiale",
menu_seed = "Seme",
menu_seaLevel = "Livello del mare",
menu_rainfall = "Pioggia",
menu_temperature = "Temperatura",
menu_continentSize = "Dimensione del continente",
menu_continentHeight = "Altezza della montagna",
menu_featureSize = "Dimensioni delle colline",
menu_featureHeight = "Altezza delle colline",
menu_mods = "Mod",

--bug reporting
reporting_uploading = "Caricamento",
reporting_zipFailed = "Spiacenti, qualcosa è andato storto durante la creazione del pacchetto di report.",
reporting_connectionFailed = "Spiacenti, impossibile connettersi al server dei bug.",
reporting_uploadFailed = "Spiacenti, il caricamento del pacchetto della segnalazione di bug non è riuscito.",
reporting_fileTooLarge = "Spiacenti, il pacchetto di segnalazioni di bug creato è troppo grande per essere caricato.",
reporting_error = "Scusa, qualcosa è andato storto.",
reporting_uploadComplete = "Grazie per la tua segnalazione, è stata inviata con successo.",
reporting_cancelled = "Caricamento annullato.",
reporting_creating = "Grazie. Creazione rapporto...",
reporting_infoText = "Aiutaci a migliorare Sapiens! Il rapporto verrà caricato in background dopo aver fatto clic su Invia. Grazie.",
reporting_pleaseWriteATitle = "Si prega di fornire una breve descrizione per questa segnalazione di bug.",
reporting_bugTitle = "Breve descrizione",
reporting_bugDescription = "Più dettagli",
reporting_email = "Email di contatto (opzionale)",
reporting_sendLogFiles = "Invia file di registro",
reporting_sendWorldSaveFiles = "Invia file di salvataggio mondiale",
reporting_submitViaEmail = "Invia tramite e-mail",
reporting_submitViaForums = "Invia tramite forum",
reporting_sendBugReport = "Invia segnalazione bug",
reporting_sendCrashReport = "Invia rapporto di arresto anomalo",
								
    reporting_crashNotification = "It looks like Sapiens crashed last time you played.\n\
We want to fix the bug that caused this, so please send us the crash report. Thanks!",
							
--mods
mods_cautionCaps = "ATTENZIONE!",
								
   mods_cautionInfo = "Mods can contain and execute both Lua and C code, which may have access to your system, files and network.\n\
Mods in Sapiens are not in any way sandboxed, so should be treated as totally separate applications, and with extreme care. They have the potential to harm your computer.\n\
Even mods that have been installed from Steam Workshop may not be safe. Only install and enable mods from mod authors that you trust.",
mods_enableMods = "Abilita mod",
mods_notAddedToWorkshop = "Non aggiunto a Steam Workshop.",
mods_addedToWorkshop = "Aggiunto a Steam Workshop. Fai clic su Carica per aggiornare i file mod su Steam.",
mods_modDeveloperTools = "Strumenti per sviluppatori mod",
mods_AddToSteamWorkshop = "Aggiungi a Steam Workshop",
mods_ContactingSteam = "Contattare Steam",
mods_acceptAgreement = "Devi prima accettare l'accordo legale di Steam Workshop. Dopo aver accettato, fai clic su Carica.",
mods_idReceived = "ID ricevuto. Inviando questo articolo, accetti i termini di servizio del workshop su:\nhttp://steamcommunity.com/sharedfiles/workshoplegalagreement\nFai clic su Carica per aggiornare i file mod su Steam.",
mods_failedToSaveID = "Impossibile salvare l'ID di Steam in",
mods_failedToAddToSteam = "Impossibile aggiungere a Steam.",
mods_UploadToSteam = "Carica su Steam",
mods_Uploadcomplete = "Caricamento completato.",
mods_failedToUploadToSteam = "Impossibile caricare su Steam.",
mods_nameDefault = "Senza nome",
mods_descriptionDefault = "Nessuna descrizione",
mods_versionDefault = "Nessuna versione",
mods_developerDefault = "Sviluppatore sconosciuto",
mods_version = "Versione",
mods_developer = "Sviluppatore",
mods_gameMods = "Mod di gioco",
mods_gameMods_info = "A livello di app, si applica a tutti i mondi.",
mods_worldMods = "Mod mondiali",	
mods_configureWorldMods = "Configura le mod per questo mondo",		
mods_configureGameMods = "Configura le mod di gioco",
mods_configureGameMods_info = "Le mod di gioco si applicano all'intero gioco e influiscono sulla tua esperienza in ogni mondo. Qui possono essere abilitati solo questi tipi di mod a livello di app.",		
mods_findMods = "Trova le mod su Steam->",
mods_makeMods = "Crea le tue mod->",
mods_websiteLink = "Sito web ->",
mods_steamLink = "Pagina di Steam ->",
mods_filesLink = "Posizione dei file ->",
mods_visitSteamWorkshopLink = "Visita Steam Workshop->",
mods_steamWorkshop = "Officina del vapore",																
-- graphics drivers
gfx_updateRequiredTitle = "Si prega di aggiornare il driver della scheda grafica.",
gfx_updateRequired_info = "Il driver rilevato su questo sistema non è aggiornato.\n\nSe non aggiorni il driver, è probabile che si verifichino problemi grafici e/o il gioco potrebbe arrestarsi in modo anomalo e uscire dal desktop durante il gioco.\n\nPer favore scaricare e installare il driver più recente dal produttore della scheda grafica. La tua scheda grafica è:",
								
--intro
intro_a = function(values)
return "Per millenni, i Sapiens hanno esplorato" .. values.worldName ..	".\n\nSmall tribes are scattered wide across the world. Travelling, gathering, hunting, and surviving."			
end,
intro_b = "Questi Sapiens sono felici, ma sono limitati dalla loro mancanza di conoscenza e ambizione.\n\nDa soli, possono sopravvivere, ma non possono mai raggiungere il loro pieno potenziale.",
intro_c = "Diventerai il guardiano di una tribù di Sapiens. Darai loro una direzione e uno scopo.\n\nIl tuo obiettivo è incoraggiarli a imparare, avanzare e crescere e, infine, creare una fiorente civiltà Sapien.",
intro_d = "Coloro che sceglierai di guidare saranno gli antenati dell'intera specie umana.\n\nScegli saggiamente la tua tribù.",
								
-- gameFailSequence
gameFailSequence_a = "Con i loro bisogni non soddisfatti, i tuoi Sapiens stanno diminuendo di numero.\n\nPurtroppo, l'ultimo membro rimasto della tua tribù è appena partito.",
gameFailSequence_b = "Fortunatamente, ci sono altre piccole tribù nelle vicinanze disposte a seguire il tuo esempio.\n\nScegli una nuova tribù per continuare.",
								
--tips/tutorial
tutorial_skip = "Salta il tutorial",
tutorial_skipAreYouSure = "Sei sicuro di voler saltare il tutorial?\nPuoi abilitarlo di nuovo in seguito nel menu delle impostazioni.",
tutorial_or = "o",
								
-- choose tribe
tutorial_title_chooseTribe = "Scegli una tribù da guidare",
tutorial_subtitle_mapNavigation = "Naviga la mappa",
tutorial_use = "- Uso",
tutorial_toMoveAnd = "muoversi, e",
tutorial_toZoom = "per ingrandire",
tutorial_subtitle_chooseTribe_title = "Guida una tribù",
tutorial_subtitle_chooseTribe_a = "- Ingrandisci vicino, quindi fai clic su alcune tribù diverse",
tutorial_subtitle_chooseTribe_b = "e scegline uno da guidare",
-- Gathering hay
tutorial_title_basicControls = "Raccolta del fieno",
tutorial_basicControls_storyText = "I tuoi sapiens vorranno un posto dove dormire stanotte, e Hay fa un letto decente. Eliminiamo un po' d'erba in modo che possa seccarsi ed essere utilizzata per i letti.",
tutorial_basicControls_navigation = "Muoviti per il mondo",
tutorial_basicControls_issueOrder = "Ordina alla tua tribù di sgombrare un po' d'erba",
tutorial_issueOrder_instructions_a = "- Clicca su un terreno erboso vicino alla tua tribù e seleziona",
tutorial_issueOrder_instructions_b = "Chiaro",
tutorial_basicControls_clearHexes = function(values)
return  string.format("Cancella %d tessere erba", values.count)				
end,
								
-- storingResources
tutorial_title_storingResources = "Aree di stoccaggio",
tutorial_storingResources_storyText = "Per immagazzinare e gestire tutte le risorse che la tua tribù trova e crea, avrai bisogno di aree di stoccaggio.\n\nOgni area di stoccaggio memorizza un solo tipo di risorsa, quindi dovrai costruirne molte altre man mano che avanzi, a almeno uno per ogni tipo di risorsa.",
tutorial_storingResources_build = function(values)
return  string.format("Costruisci %d aree di archiviazione", values.count)				
end,
tutorial_storingResources_subTitle_accessWith = "- Accedi al menu di costruzione con",
tutorial_storingResources_subTitle_andPlace = "- Posiziona aree di stoccaggio vicino alla tua tribù",
tutorial_storingResources_store = function(values)
return  string.format("Memorizza %d %s", values.count, values.typeName)				
end,
tutorial_storingResources_storeTip_a = "- Potrebbe essere necessario attendere che l'erba si asciughi",
tutorial_storingResources_storeTip_b = "Puoi raccogliere rami dagli alberi",
								
-- game speed controls
tutorial_title_speedControls = "Controllo della velocità di gioco",
tutorial_subtitle_togglePause = "Attiva/disattiva pausa con",
tutorial_subtitle_toggleFastForward = "Passa velocemente avanti con",
								
--multiselect
tutorial_title_multiselect = "Selezione di più cose",
tutorial_description_multiselect = "Puoi selezionare più oggetti o tessere terreno contemporaneamente, quindi emettere o annullare ordini per tutti contemporaneamente.\n\nQuesto è particolarmente utile per ripulire grandi aree o raccogliere da molti alberi.",
tutorial_task_multiselect = function(values)
return  string.format("Emetti qualsiasi ordine per %d o più cose contemporaneamente", values.count)				
end,
tutorial_task_multiselect_subtitle = "- Fare clic su qualsiasi oggetto o piastrella di terra",
tutorial_task_multiselect_subtitle_b = "- Colpo Select More",		
tutorial_task_multiselect_subtitle_c = "- Emettere qualsiasi ordine per tutti loro",
								
-- beds
tutorial_title_beds = "Dormire nei letti",
tutorial_beds_storyText = "I Sapiens saranno più felici se dormiranno su un letto, piuttosto che sul terreno duro. Quindi ora che abbiamo abbastanza fieno immagazzinato, costruiamo alcuni letti.",
tutorial_beds_build = function(values)
return  string.format("Posiziona %d più letti", values.count)				
end,
tutorial_beds_subTitle_accessWith = "- Accedi al menu di costruzione con",
tutorial_beds_subTitle_andPlace = "- Metti i letti vicino alla tua tribù",
tutorial_beds_waitForBuild = "Aspetta che i letti siano completati",
tutorial_beds_waitForBuild_tip = "- Eliminare più erba per creare più fieno, se necessario",
								
--roleAssignment
tutorial_title_roleAssignment = "Come assegnare i ruoli",
tutorial_description_roleAssignment = "Quando un sapien scopre una nuova tecnologia, ne diventa esperto e gli verrà automaticamente assegnato un ruolo che gli consentirà di completare compiti relativi a quell'abilità.\n\nDovresti assegnare ruoli anche ai sapiens manualmente. Ciò contribuirà a tenere tutti occupati e ti consentirà di concentrare la tua tribù sulle aree in cui sono più necessari.",
tutorial_task_roleAssignment = "Assegna un sapien a un nuovo ruolo",
tutorial_task_roleAssignment_subtitle_a = "- Colpo",
tutorial_task_roleAssignment_subtitle_b = "quindi seleziona il menu della tribù",
tutorial_task_roleAssignment_subtitle_c = "- Selezionare i Ruoli",		
tutorial_task_roleAssignment_subtitle_d = "- Assegna un sapien a qualsiasi ruolo",
								
-- research
tutorial_title_research = "Indagare per avanzare",
tutorial_research_storyText = "Per avanzare, i sapiens devono investigare il mondo che li circonda.\n\nQuesto porta a scoperte tecnologiche che sbloccheranno nuove cose da costruire e creare.",
tutorial_research_branch = "Indaga su una filiale",
tutorial_research_rock = "Indaga su una roccia",
tutorial_research_hay = "Indaga sul fieno",
								
-- tools
tutorial_title_tools = "Aree e strumenti di lavorazione",
tutorial_tools_storyText = "Grazie alla conoscenza del knapping delle rocce, i sapiens ora hanno la capacità di creare strumenti.\n\nAsce e coltelli a mano sono molto utili per cominciare, quindi la tua tribù dovrebbe crearne alcuni ora.\n\nIl modo migliore per gestire le attività di creazione della tua tribù è costruire prima aree di lavorazione designate.",
tutorial_tools_buildCraftAreas = function(values)
return  string.format("Costruisci %d aree di creazione", values.count)				
end,
tutorial_tools_craftHandAxes = function(values)
return  string.format("Crea e conserva %d asce in pietra", values.count)				
end,
tutorial_tools_craftKnives = function(values)
return  string.format("Crea e conserva %d coltelli di pietra", values.count)				
end,
								
-- fire
tutorial_title_fire = "Accendere un fuoco",
tutorial_fire_storyText = "Il fuoco è un'importante scoperta precoce che fornisce luce di notte, aiuta a mantenere calda la tua tribù quando fa freddo e permette di cucinare il cibo.\n\nOra sarebbe un buon momento per accendere un fuoco da campo.",
tutorial_fire_place = "Metti un fuoco da campo",
tutorial_fire_waitForBuild = "Aspetta che il fuoco sia acceso e acceso",
								
-- thatchBuilding
tutorial_title_thatchBuilding = "Costruire con paglia",
tutorial_thatchBuilding_storyText = "Con la nuova comprensione della costruzione di paglia, ora sarebbe un ottimo momento per la tribù per iniziare a lavorare su alcune strutture di base.\n\nSapiens sarà più felice se i loro letti sono al coperto, e anche le risorse immagazzinate sotto un tetto dureranno più a lungo.",
tutorial_thatchBuilding_place = "Posiziona una capanna/tetto di paglia",
tutorial_thatchBuilding_waitForBuild = "Aspetta che la struttura venga costruita",
								
-- food
tutorial_title_food = "Fame e cibo",
tutorial_food_storyText = "I tuoi sapiens iniziano ad avere fame. I Sapiens non raccolgono frutti da soli, devi impartire ordini per raccogliere, cacciare e conservare il cibo.\n\nNon raccogliere tutto in una volta, però, la maggior parte dei frutti durerà sull'albero fino alla prossima stagione, ma marcirà rapidamente se raccolto e lasciato fuori.",
tutorial_food_storeTask = function(values)
return  string.format("Raccogli e immagazzina %d risorse alimentari", values.count)				
end,
tutorial_food_storeTask_subTitle = "I frutti crescono su alcuni tipi di alberi e cespugli",
								
-- farming
tutorial_title_farming = "agricoltura",
tutorial_farming_storyText = "Ora che i bisogni immediati della tribù sono stati soddisfatti, dobbiamo iniziare a pianificare in anticipo.\n\nMan mano che la tribù cresce, avrà bisogno di coltivare abbastanza prodotti per sfamare tutti.",
tutorial_farming_digging = "Scopri scavare",
tutorial_farming_planting = "Scopri la semina",
tutorial_farming_plantXTrees = function(values)
return  string.format("Pianta %d alberi da frutto o piante", values.count)				
end,
								
-- music
tutorial_title_music = "Fare musica",
tutorial_music_storyText = "La musica rende i sapiens più felici e leali, e i sapiens musicali possono persino diventare tristi se non ascoltano o suonano musica da molto tempo.",
tutorial_music_discoverBoneCarving = "Scopri la scultura ossea",
tutorial_music_playFlute = "Suona un flauto",
								
-- routes
tutorial_title_routes = "Percorsi e logistica",
tutorial_routes_storyText = "Sapiens può spostare le risorse da un'area di archiviazione all'altra utilizzando percorsi.\n\nI percorsi sono utili per distribuire le risorse dove sono necessarie. Possono anche essere utilizzati per trasferire risorse su grandi distanze.",
tutorial_routes_create = "Crea un percorso di trasferimento",
tutorial_routes_create_subtitle_a = "- Apri il menu e fai clic su Routes",		
tutorial_routes_create_subtitle_b = "- Aggiungi un nuovo percorso, quindi fai clic su Add Stops",		
tutorial_routes_create_subtitle_c = "- Fare clic sull'area di archiviazione di origine",
tutorial_routes_create_subtitle_d = "- Quindi fare clic su un'area di archiviazione di destinazione vuota",
tutorial_routes_doTransfer = "Trasferisci qualsiasi articolo da un'area di stoccaggio all'altra",
								
-- paths
tutorial_title_paths = "Percorsi e Strade",
tutorial_paths_storyText = "I Sapiens possono muoversi più velocemente sui sentieri, il che rende la tua tribù più efficiente.",
tutorial_paths_buildXPaths = function(values)
return  string.format("Costruisci %d segmenti di percorso", values.count)				
end,
								
-- woodBuilding
tutorial_title_woodBuilding = "Costruire in legno",
tutorial_woodBuilding_storyText = "Le capanne di paglia sono meglio di niente, ma la tua tribù dovrà iniziare a costruire con materiali più avanzati se la loro nuova civiltà vuole resistere alla prova del tempo.",
tutorial_woodBuilding_chopTree = "Taglia un albero",
tutorial_woodBuilding_splitLog = "Dividi un registro",
tutorial_woodBuilding_buildWall = "Costruisci un muro di tronchi diviso",
-- advancedTools
tutorial_title_advancedTools = "Creazione di strumenti avanzati",
tutorial_advancedTools_storyText = "Attaccando semplici strumenti di roccia a un manico di legno, la tua tribù può creare strumenti più avanzati che possono durare più a lungo, rendere alcune attività più veloci e sbloccare la possibilità di cacciare prede più grandi.",
tutorial_advancedTools_driedFlax = function(values)
return  string.format("Trova, raccogli e conserva %d lino essiccato", values.count)				
end,
tutorial_advancedTools_twine = function(values)
return  string.format("Crea e conserva %d spago", values.count)				
end,
tutorial_advancedTools_pickAxe = "Crea un piccone",
tutorial_advancedTools_spear = "Crea una lancia",
tutorial_advancedTools_hatchet = "Crea un'accetta",
-- cookingMeat
tutorial_title_cookingMeat = "Cucinare la carne",
tutorial_cookingMeat_storyText = "Dopo una caccia di successo, i tuoi sapiens devono preparare la carcassa per renderla pronta da mangiare. Per fare questo, dovranno macellare e poi cuocere la carne.",
tutorial_cookingMeat_butcher = "Macella una carcassa",
tutorial_cookingMeat_cook = "Cuocere un po' di carne",
-- worldMap
tutorial_title_worldMap = "Mappa del mondo",
tutorial_worldMap_task = "Guarda il mondo dall'alto con",
-- recruitment
tutorial_title_recruitment = "Reclutamento",
tutorial_recruitment_storyText = "A volte le tribù nomadi si aggirano per la zona o vengono in cerca di cibo.\n\nQuesta è una buona opportunità per far crescere la tribù, poiché molti decideranno di unirsi se li invitiamo.",
tutorial_recruitment_task = "Invita un visitatore a unirsi alla tribù",
								
-- orderLimit
tutorial_title_orderLimit = "Limite d'ordine",
tutorial_orderLimit_storyText = function(values)
return  string.format("I tuoi sapiens sceglieranno sempre l'ordine disponibile più vicino che corrisponde ai loro ruoli ed esigenze, quindi è importante non fare la coda per troppi ordini che non sono realmente richiesti.\n\nPer aiutarti in questo, c'è un limite a livello di tribù di %d ordini per sapien. Dopodiché, ignoreranno i nuovi ordini fino al completamento di quelli precedenti.\n\nSe un ordine è contrassegnato da un triangolo giallo con Maximum orders reached, then you can prioritize it in the radial menu.",
values.allowedPlansPerFollower)
end,
tutorial_orderLimit_task = "Dai la priorità a qualsiasi ordine contrassegnato Maximum orders reached",		
								
-- notifications
tutorial_title_notifications = "Notifiche",
tutorial_notifications_task = "Zoom sulla notifica più recente",
-- completion
tutorial_title_completion = "Tutorial completo!",
tutorial_completion_storyText = "Ben fatto!\n\nLa tua tribù è appena agli inizi, ma da qui sei da solo.\n\nContinua a esplorare, creare e investigare, far avanzare e far crescere la tua tribù. Prenditi cura dei tuoi sapiens, costruisci una città vivace, guida la tua tribù verso un futuro nuovo e prospero.\n\nBuona fortuna!",
								
--done
tutorial_subtitle_movement = "Movimento:",
tutorial_subtitle_zoom = "Ingrandisci:",
tutorial_subtitle_movementSpeed = "Muoviti più velocemente o più lentamente:",
tutorial_title_worldNavigation = "Navigazione mondiale",
tutorial_title_investigate = "Indagine e scoperte",
tutorial_subtitle_investigateLine1 = "L'indagine sugli oggetti porta a scoperte che sbloccano nuove cose da creare e costruire.",
tutorial_subtitle_investigateLine2 = "Seleziona una roccia o un ramo ed esaminalo.",
buildContext_title = "Costruisci controlli",
buildContext_placeTitle = "Posto:",
buildContext_place = "Posto",
buildContext_placeRefine = "Posiziona e rifinisci:",
buildContext_placeWithoutBuild = "Posiziona senza emettere ordine di costruzione:",
buildContext_cancel = "Annulla:",
buildContext_rotate = "Ruotare:",
buildContext_rotate90 = "Ruota di 90 gradi:",
buildContext_moveXZ = "Sposta orizzontalmente:",
buildContext_moveY = "Sposta su/giù:",
buildContext_disableSnapping = "Disabilita lo snap:",
								
--mouse
mouse_left = "Tasto sinistro del mouse",
mouse_right = "Pulsante destro del mouse",
mouse_left_drag = "Trascina con",
mouse_right_drag = "Trascina con il tasto destro del mouse",
mouse_wheel = "Rotellina del mouse",
creditsText_dave = "Creato da David Frampton",
creditsText_music = "Colonna sonora originale di John Konsalakis e David Frampton",
creditsText_soundtrackLinkText = "Dettagli della colonna sonora",
creditsText = [[
Voice Acting by Emma Frampton, Ethan Frampton, & David Frampton
Community Management: Milla Koutsos
Promotional Illustrations by Jérémy Forveille
Atmosphere rendering based on the work by Eric Bruneton
Audio Engine: FMOD Studio by Firelight Technologies Pty Ltd.
Physics: Bullet Physics
Serialization: Cereal - Grant, W. Shane and Voorhies, Randolph (2017)
Networking: Enet - Lee Salzman
Sapiens uses the amazing LuaJIT library by Mike Pall
Sapiens also uses LuaBridge by Nathan Reed, Vinnie Falco and others
Vocals in Sapiens are in"toki pona", the constructed language by Sonja Lang - tokipona.org				
								
Many thanks for the huge support, testing, feedback and help from many others. An especially large thanks goes to the alpha testers, and also members of the community Discord server, and those who gave feedback on the devlog videos on YouTube. I couldn't have made Sapiens without you.

And most of all, thank you to my amazing wife Emma, who supported our family and me through this very long period of development, sacrificing her own career to give me the time to work on mine. This game is every bit as much the result of Emma's hard work, sacrifice, and dedication as it is mine.
]],
								
    -- orderStatus
    -- values for these function usally include .name, the noun variant of the inProgressName. Also planName, which is the name of the plan, instead of the in-progress variant provided with planText.

    orderStatus_deliverTo = function(values)
        return values.inProgressName .. " " .. values.heldObjectName .. " to " .. values.retrievedObjectName .. values.logisticsPostfix
    end,
    orderStatus_deliverForConstruction = function(values)
            if values.planText then
                if values.retrievedObjectConstructableTypeName then
                return values.inProgressName .. " " .. values.heldObjectName .. " per " .. values.planText .. " " .. values.retrievedObjectConstructableTypeName .. values.logisticsPostfix
                else
                return values.inProgressName .. " " .. values.heldObjectName .. " per " .. values.planText .. values.logisticsPostfix
                end
            end
        return values.inProgressName .. " " .. values.heldObjectName .. " per costruire a " .. values.retrievedObjectName
    end,
    orderStatus_deliverForFuel = function(values)
        return values.inProgressName .. " " .. values.heldObjectName .. " per alimentare a " .. values.retrievedObjectName
    end,
    orderStatus_pickupObject = function(values)
            if values.planText then
                if values.retrievedObjectConstructableTypeName then
                return values.inProgressName .. " " .. values.pickupObjectName .. " per " .. values.planText .. " at " .. values.retrievedObjectConstructableTypeName
                else
                return values.inProgressName .. " " .. values.pickupObjectName .. " per " .. values.planText
                end
            end
        return values.inProgressName .. " " .. values.pickupObjectName
    end,
    orderStatus_pickupObjectToEat = function(values)
        return values.inProgressName .. " " .. values.pickupObjectName .. " da mangiare"
    end,
    orderStatus_pickupObjectToWear = function(values)
        return values.inProgressName .. " " .. values.pickupObjectName .. " da indossare"
    end,
    orderStatus_pickupObjectToPlayWith = function(values)
        return values.inProgressName .. " " .. values.pickupObjectName .. " per usare con"
    end,
    orderStatus_crafting = "fabbricazione",
    orderStatus_research = "ricerca",
    orderStatus_moveObjectForAction = function(values)
        return "In movimento" .. values.objectName .. " per " .. values.action
    end,
    orderStatus_talkingTo = function(values)
        return "Parlando a" .. values.objectName
    end,

    --b13
    orderStatus_addObjectName = function(values)
        return values.inProgressName .. " " .. values.objectName
    end,
    orderStatus_getLogisticsPostfix = function(values)
        return " (" .. values.routeName .. ")"
    end,
    orderStatus_addLogisticsPostfix = function(values)
        return values.inProgressName .. " " .. values.logisticsPostfix
    end,
    orderStatus_buildConstructablePlan = function(values)
        return values.planText .. " " .. values.retrievedObjectConstructableTypeName
    end,
    --/b13
}

local function getTimeSplit(durationSeconds, dayLength, yearLength)
    local result = {
        years = 0,
        days = 0,
        hours = 0,
    }
    
    if durationSeconds >= yearLength then
        result.years = math.floor(durationSeconds / yearLength)
        durationSeconds = durationSeconds - result.years * yearLength
    end
    
    if durationSeconds >= dayLength then
        result.days = math.floor(durationSeconds / dayLength)
        durationSeconds = durationSeconds - result.days * dayLength
    end
    
    if durationSeconds > 0 then
        result.hours = math.floor(durationSeconds / dayLength * 24)
    end

    return result
end

local function getTimeDurationDescriptionFromSplitTime(timeSplit)
    local result = ""
    local empty = true
    if timeSplit.years > 0 then
        local postfix = " anno"
        if timeSplit.years > 1 then
            postfix = " anni"
        end
        result = mj:tostring(timeSplit.years) .. postfix
        empty = false
    end

    if timeSplit.days > 0 then
        local postfix = " giorno"
        if timeSplit.days > 1 then
            postfix = " giorni"
        end

        if not empty then
            result = result .. ", "
        end
        
        result = result .. mj:tostring(timeSplit.days) .. postfix
        empty = false
    end
    
    if timeSplit.hours > 0 then
        local postfix = " ora"
        if timeSplit.hours > 1 then
            postfix = " ore"
        end

        if not empty then
            result = result .. ", "
        end
        
        result = result .. mj:tostring(timeSplit.hours) .. postfix
        empty = false
    else 
        if empty then
        return "< 1 ora"
        end
    end

    return result
end

function localizations.getTimeDurationDescription(durationSeconds, dayLength, yearLength)
    local timeSplit = getTimeSplit(durationSeconds, dayLength, yearLength)
    return getTimeDurationDescriptionFromSplitTime(timeSplit)
end

function localizations.getTimeRangeDescription(durationSecondsMin, durationSecondsMax, dayLength, yearLength)
    local minHourCount = math.floor(durationSecondsMin / dayLength * 24)
    local maxHourCount = math.floor(durationSecondsMax / dayLength * 24)
    if minHourCount == maxHourCount then
        return localizations.getTimeDurationDescription(durationSecondsMin, dayLength, yearLength)
    end

    if minHourCount == 0 then
        local maxDescription = localizations.getTimeDurationDescription(durationSecondsMax, dayLength, yearLength)
        return "< " .. maxDescription
    end
    
    local timeSplitMin = getTimeSplit(durationSecondsMin, dayLength, yearLength)
    local timeSplitMax = getTimeSplit(durationSecondsMax, dayLength, yearLength)

    if (timeSplitMin.years == 0 and timeSplitMax.years == 0) then
        if (timeSplitMin.days == 0 and timeSplitMax.days == 0) then
        return mj:tostring(timeSplitMin.hours) .. " - " .. mj:tostring(timeSplitMax.hours) .. " hours"
        end
        if (timeSplitMin.hours == 0 and timeSplitMax.hours == 0) then
        return mj:tostring(timeSplitMin.days) .. " - " .. mj:tostring(timeSplitMax.days) .. " days"
        end
    elseif (timeSplitMin.days == 0 and timeSplitMax.days == 0) and (timeSplitMin.hours == 0 and timeSplitMax.hours == 0) then
        return mj:tostring(timeSplitMin.years) .. " - " .. mj:tostring(timeSplitMax.years) .. " years"
    end

    local minDescription = getTimeDurationDescriptionFromSplitTime(timeSplitMin)
    local maxDescription = getTimeDurationDescriptionFromSplitTime(timeSplitMax)

    return minDescription .. " - " .. maxDescription

    --[[local minHourCount = math.floor(durationSecondsMin / dayLength * 24)
    local maxHourCount = math.floor(durationSecondsMax / dayLength * 24)
    if minHourCount == maxHourCount then
        return localizations.getTimeDurationDescription(durationSecondsMin, dayLength, yearLength)
    end

    local maxDescription = localizations.getTimeDurationDescription(durationSecondsMax, dayLength, yearLength)
    if minHourCount == 0 then
        return "< " .. maxDescription
    end

    local minDescription = localizations.getTimeDurationDescription(durationSecondsMin, dayLength, yearLength)
    return minDescription .. " - " .. maxDescription]]
end
								
function localizations.getBiomeForestDescription(biomeTags)
local typeString = nil
								
if biomeTags.coniferous then
if biomeTags.birch then
typeString = "pino e betulla"			
elseif biomeTags.bamboo then
typeString = "pino e bambù"			
else
typeString = "pino"			
end
else
typeString = "betulla"			
end
								
if not typeString then
return "Niente alberi."			
end
								
local forestString = true
if biomeTags.mediumForest then
forestString = string.format("%s foresta.", mj:capitalize(typeString))				
elseif biomeTags.denseForest then
forestString = string.format("Una fitta foresta di %s.", typeString)				
elseif biomeTags.sparseForest then
forestString = string.format("%s alberi.", mj:capitalize(typeString))				
elseif biomeTags.verySparseForest then
forestString = string.format("Pochissimi %s alberi.", typeString)				
else
return "Niente alberi."			
end
								
return  forestString
								
end
								
function localizations.getBiomeMainDescription(biomeTags)
local descriptionString = nil
if biomeTags.tropical then
descriptionString = "Tropicale"			
elseif biomeTags.polar or biomeTags.icecap or biomeTags.heavySnowSummer or biomeTags.medSnowSummer or biomeTags.lightSnowSummer then
descriptionString = "Ghiacciato"			
elseif biomeTags.temperate then
descriptionString = "Temperato"			
elseif biomeTags.dry then
descriptionString = "Asciutto"			
end
								
local mainAdded = false
								
local function addMain(value)
if descriptionString then
            descriptionString = descriptionString .. " " .. value .. "."		
else
descriptionString = mj:capitalize(value) .."."			
end
mainAdded = true
end
								
if biomeTags.desert then
addMain("deserto")				
elseif biomeTags.steppe then
addMain("steppa")				
elseif biomeTags.rainforest then
addMain("foresta pluviale")				
elseif biomeTags.savanna then
addMain("savana")				
elseif biomeTags.tundra then
addMain("tundra")				
end
								
if not mainAdded then
if not descriptionString then
return ""
end
return  descriptionString .."."			
end
return  descriptionString
end
								
function localizations.getBiomeTemperatureDescription(biomeTags)
								
local descriptionString = nil
								
if biomeTags.temperatureSummerVeryHot then
descriptionString = "Estate molto calda."			
elseif biomeTags.temperatureSummerHot then
descriptionString = "Estate calda."			
elseif biomeTags.temperatureSummerCold then
descriptionString = "Fredda estate."			
elseif biomeTags.temperatureSummerVeryCold then
descriptionString = "Estate molto fredda."			
else
descriptionString = "Estate moderata."			
end
if biomeTags.temperatureWinterVeryHot then
descriptionString = descriptionString .. "Inverno molto caldo."			
elseif biomeTags.temperatureWinterHot then
descriptionString = descriptionString .. "Caldo inverno."			
elseif biomeTags.temperatureWinterCold then
descriptionString = descriptionString .. "Inverno freddo."			
elseif biomeTags.temperatureWinterVeryCold then
descriptionString = descriptionString .. "Inverno molto freddo."			
else
descriptionString = descriptionString .. "Inverno moderato."
   end

    return descriptionString
end

function localizations.getBiomeFullDescription(biomeTags) --b13
    return localizations.getBiomeMainDescription(biomeTags) .. " " .. localizations.getBiomeForestDescription(biomeTags) .. " " .. localizations.getBiomeTemperatureDescription(biomeTags)
end

--mj:log("localizations count:", #(localizations.localizations))
        
return localizations